﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace SuperSession.Controllers
{
    public class SuperSessionController : Controller
    {
        private readonly string _connectionstring = ConfigurationManager.ConnectionStrings["SupeSessionDB"].ConnectionString;
        public static string _LogFilePath = "C:\\LogSheetExport";
        public static string _LogFileFullPath = "C:\\LogSheetExport\\ErrorLog.txt";
        //log file
        public static void LogToTextFile(int ExId, string ExMessage, string ExDetails, string ExStackTrace)
        {
            try
            {

                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.AppendFormat("Exception Date: {0}", DateTime.Now);
                stringBuilder.AppendFormat("{0}Exception From:", Environment.NewLine);
                stringBuilder.AppendFormat("{0}{1}: {2}", Environment.NewLine, ExMessage, ExId);
                stringBuilder.AppendFormat("{0}{0}Exception Information{0}{1}", Environment.NewLine, ExDetails);
                stringBuilder.AppendFormat("{0}{0}Stack Trace{0}{1}", Environment.NewLine, ExStackTrace);
                if (!Directory.Exists(_LogFilePath))
                {
                    Directory.CreateDirectory(_LogFilePath);
                }

                using (StreamWriter streamWriter = System.IO.File.AppendText(_LogFileFullPath))
                {
                    streamWriter.WriteLine(stringBuilder.ToString());
                    streamWriter.WriteLine("----------------------------------");
                }
            }
            catch (Exception)
            {
            }
        }

        [HttpGet]// Initial loading fetch all the requried data and pass it in view bag
        public ActionResult Supersession(int page = 1)
        {
            int currentPage = page;
            int pageSize = 25;

            try
            {
                //throw new Exception();
                using (var connection = new SqlConnection(_connectionstring))
                {
                    connection.Open();
                    var Procedure = "usp_GetSupersessionIndexData";
                    using (var command = new SqlCommand(Procedure, connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@CurrentPage", currentPage);
                        command.Parameters.AddWithValue("@PageSize", pageSize);

                        using (var reader = command.ExecuteReader())
                        {
                            PopulateSummaryData(reader);
                            PopulateModalDataSources(reader);
                            PopulateRulesAndPagination(reader, currentPage, pageSize);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogToTextFile(ex.HResult, ex.GetType().FullName + ":" + ex.Message, ex.TargetSite.ToString(), ex.StackTrace);
                ViewBag.ErrorMessage = "An error occurred while fetching data: " + ex.Message;
            }
            return View();
        }
        [HttpGet] //Get all the records from parts table
        public JsonResult GetAllParts()
        {
            var parts = new List<PartViewModel>();
            try
            {
                using (var connection = new SqlConnection(_connectionstring))
                {

                    string sql = "SELECT PartID, Prefix, PartNumber, Description FROM Parts ORDER BY PartNumber";
                    using (var command = new SqlCommand(sql, connection))
                    {
                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                parts.Add(new PartViewModel
                                {
                                    PartID = (int)reader["PartID"],
                                    Prefix = reader["Prefix"].ToString(),
                                    PartNumber = reader["PartNumber"].ToString(),
                                    Description = reader["Description"].ToString()
                                });
                            }
                        }
                    }
                }
                return Json(parts, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                LogToTextFile(ex.HResult, ex.GetType().FullName + ":" + ex.Message, ex.TargetSite.ToString(), ex.StackTrace);
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        [HttpPost]//Add supersession using sp 
        public JsonResult AddSupersession(AddSupersessionViewModel model)
        {

            if (model == null || model.OriginalParts == null || model.SupersedingParts == null)
            {
                return Json(new { success = false, message = "Invalid data received." });
            }
            if (model.OriginalParts.Count == 0 || model.SupersedingParts.Count == 0)
            {
                return Json(new { success = false, message = "You must select at least one 'From' part and one 'To' part." });
            }

            try
            {
                var xmlBuilder = new StringBuilder();
                xmlBuilder.Append("<Parts>");
                foreach (var part in model.OriginalParts)
                {
                    xmlBuilder.Append("<Part>");
                    xmlBuilder.AppendFormat("<PartID>{0}</PartID>", part.PartID);
                    xmlBuilder.AppendFormat("<PartRole>{0}</PartRole>", "O");
                    xmlBuilder.AppendFormat("<Quantity>{0}</Quantity>", part.Quantity);
                    xmlBuilder.Append("</Part>");
                }
                foreach (var part in model.SupersedingParts)
                {
                    xmlBuilder.Append("<Part>");
                    xmlBuilder.AppendFormat("<PartID>{0}</PartID>", part.PartID);
                    xmlBuilder.AppendFormat("<PartRole>{0}</PartRole>", "S");
                    xmlBuilder.AppendFormat("<Quantity>{0}</Quantity>", part.Quantity);
                    xmlBuilder.Append("</Part>");
                }
                xmlBuilder.Append("</Parts>");

                using (var connection = new SqlConnection(_connectionstring))
                {
                    var Procedure = "usp_AddSupersessionRule";
                    using (var command = new SqlCommand(Procedure, connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@CompanyID", model.CompanyID);
                        command.Parameters.AddWithValue("@EffectiveDate", model.EffectiveDate);
                        command.Parameters.AddWithValue("@SupersessionTypeID", model.SupersessionTypeID);
                        command.Parameters.AddWithValue("@ConsumptionCodeID", model.ConsumptionCodeID);
                        command.Parameters.AddWithValue("@ReplacingCodeID", (object)model.ReplacingCodeID ?? DBNull.Value);
                        command.Parameters.AddWithValue("@Remarks", model.Remarks);
                        command.Parameters.AddWithValue("@IsActive", model.IsActive);
                        command.Parameters.AddWithValue("@CreatedByUserID", 101);
                        var xmlParameter = new SqlParameter("@PartsXML", SqlDbType.Xml)
                        {
                            Value = xmlBuilder.ToString()
                        };
                        command.Parameters.Add(xmlParameter);

                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }
                return Json(new { success = true, message = "Supersession rule added successfully!" });
            }
            catch (Exception ex)
            {
                LogToTextFile(ex.HResult, ex.GetType().FullName + ":" + ex.Message, ex.TargetSite.ToString(), ex.StackTrace);
                return Json(new { success = false, message = "An error occurred while saving the rule." });
            }
        }
        [HttpPost]//Edit supersession using sp 
        public JsonResult EditSupersession(UpdateSupersessionViewModal model)
        {
            if (model == null || model.RuleID <= 0)
            {
                return Json(new { success = false, message = "Invalid Rule ID Provided" });
            }
            else if (model.OriginalParts == null || model.SupersedingParts == null || model.OriginalParts.Count == 0 || model.SupersedingParts.Count == 0)
            {
                return Json(new { success = false, message = "Parts Must be Added before submitting " });
            }
            try
            {

                var xmlBuilder = new StringBuilder();
                xmlBuilder.Append("<Parts>");
                foreach (var part in model.OriginalParts)
                {
                    xmlBuilder.Append("<Part>");
                    xmlBuilder.AppendFormat("<PartID>{0}</PartID>", part.PartID);
                    xmlBuilder.AppendFormat("<PartRole>{0}</PartRole>", "O");
                    xmlBuilder.AppendFormat("<Quantity>{0}</Quantity>", part.Quantity);
                    xmlBuilder.Append("</Part>");
                }
                foreach (var part in model.SupersedingParts)
                {
                    xmlBuilder.Append("<Part>");
                    xmlBuilder.AppendFormat("<PartID>{0}</PartID>", part.PartID);
                    xmlBuilder.AppendFormat("<PartRole>{0}</PartRole>", "S");
                    xmlBuilder.AppendFormat("<Quantity>{0}</Quantity>", part.Quantity);
                    xmlBuilder.Append("</Part>");
                }
                xmlBuilder.Append("</Parts>");

                using (var connection = new SqlConnection(_connectionstring))
                {
                    var Procedure = "usp_UpdateSupersessionRule";
                    using (var command = new SqlCommand(Procedure, connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@RuleID", model.RuleID);
                        //command.Parameters.AddWithValue("@CompanyID", model.CompanyID);
                        command.Parameters.AddWithValue("@EffectiveDate", model.EffectiveDate);
                        command.Parameters.AddWithValue("@SupersessionTypeID", model.SupersessionTypeID);
                        command.Parameters.AddWithValue("@ConsumptionCodeID", model.ConsumptionCodeID);
                        command.Parameters.AddWithValue("@ReplacingCodeID", (object)model.ReplacingCodeID ?? DBNull.Value);
                        command.Parameters.AddWithValue("@Remarks", model.Remarks);
                        command.Parameters.AddWithValue("@IsActive", model.IsActive);
                        command.Parameters.AddWithValue("@ModifiedByUserID", 102);
                        var xmlParameter = new SqlParameter("@PartsXML", SqlDbType.Xml)
                        {
                            Value = xmlBuilder.ToString()
                        };
                        command.Parameters.Add(xmlParameter);

                        connection.Open();
                        command.ExecuteNonQuery();

                    }
                }
                return Json(new { success = true, message = "SuereSession Is Updated Successfully" });
            }
            catch (Exception ex)
            {
                LogToTextFile(ex.HResult, ex.GetType().FullName + ":" + ex.Message, ex.TargetSite.ToString(), ex.StackTrace);
                return Json(new { success = false, message = "Failed to Edit the SuperSession" });
            }

        }
        [HttpPost]//Delete supersession using sp 
        public JsonResult DeleteSelectedSupersessions(string ruleIDList)
        {
            if (string.IsNullOrEmpty(ruleIDList))
            {
                return Json(new { success = false, message = "No rules were selected for deletion." });
            }

            try
            {
                using (var connection = new SqlConnection(_connectionstring))
                {
                    using (var command = new SqlCommand("usp_DeleteSupersessionRules", connection))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@RuleIDList", ruleIDList);
                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                }

                return Json(new { success = true, message = "Selected supersession rules deleted successfully!" });
            }
            catch (Exception ex)
            {
                LogToTextFile(ex.HResult, ex.GetType().FullName + ":" + ex.Message, ex.TargetSite.ToString(), ex.StackTrace);
                return Json(new { success = false, message = "An error occurred while deleting the selected rules." });
            }
        }
        [HttpGet]//Get the Filtered supersessions
        public JsonResult GetFilteredRules(int page = 1, string searchTerm = null, int? typeId = null, bool? status = null)
        {
            var result = new FilteredResultViewModel
            {
                Rules = new List<SupersessionRuleViewModel>(),
                Pagination = new PaginationViewModel { CurrentPage = page, PageSize = 25 }
            };

            try
            {
                using (var connection = new SqlConnection(_connectionstring))
                {
                    using (var command = new SqlCommand("usp_GetFilteredSupersessionRules", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Add all necessary parameters
                        command.Parameters.AddWithValue("@CurrentPage", page);
                        command.Parameters.AddWithValue("@PageSize", result.Pagination.PageSize);
                        command.Parameters.AddWithValue("@SearchTerm", (object)searchTerm ?? DBNull.Value);
                        command.Parameters.AddWithValue("@SupersessionTypeID", (object)typeId ?? DBNull.Value);
                        command.Parameters.AddWithValue("@IsActive", (object)status ?? DBNull.Value);

                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            // --- Read Result Set 1: The new total record count ---
                            if (reader.Read())
                            {
                                result.Pagination.TotalRecords = (int)reader["TotalFilteredRecords"];
                            }

                            // --- Read Result Set 2: The filtered list of rules ---
                            reader.NextResult();
                            var rulesDictionary = new Dictionary<int, SupersessionRuleViewModel>();
                            while (reader.Read())
                            {
                                int ruleId = (int)reader["RuleID"];
                                if (!rulesDictionary.ContainsKey(ruleId))
                                {
                                    var rule = new SupersessionRuleViewModel
                                    {
                                        RuleID = ruleId,
                                        CompanyName = reader["CompanyName"].ToString(),
                                        SupersessionType = reader["SupersessionType"].ToString(),
                                        ConsumptionCode = reader["ConsumptionCode"].ToString(),
                                        ReplacingCode = reader["ReplacingCode"].ToString(),
                                        EffectiveDate = reader["EffectiveDate"].ToString(),
                                        IsActive = (bool)reader["IsActive"],
                                        Remarks = reader["Remarks"].ToString()
                                    };
                                    rulesDictionary.Add(ruleId, rule);
                                    result.Rules.Add(rule);
                                }

                                // Add the part detail to the correct rule
                                if (reader["PartID"] != DBNull.Value)
                                {
                                    var part = new PartViewModel
                                    {
                                        PartID = (int)reader["PartID"],
                                        Prefix = reader["Prefix"].ToString(),
                                        PartNumber = reader["PartNumber"].ToString(),
                                        Description = reader["Description"].ToString(),
                                        Quantity = (decimal)reader["Quantity"]
                                    };

                                    if (reader["PartRole"].ToString() == "O")
                                    {
                                        rulesDictionary[ruleId].OriginalParts.Add(part);
                                    }
                                    else
                                    {
                                        rulesDictionary[ruleId].SupersedingParts.Add(part);
                                    }
                                }
                            }
                        }
                    }
                }
                return Json(new { success = true, data = result }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        private void PopulateSummaryData(SqlDataReader reader) //Helper Method
        {
            var summaryData = new SummaryDataViewModel();
            if (reader.Read())
            {
                summaryData.TotalRules = (int)reader["TotalRules"];
                summaryData.ActiveRules = (int)reader["ActiveRules"];
                summaryData.OneToOneCount = (int)reader["OneToOneCount"];
                summaryData.OneToManyCount = (int)reader["OneToManyCount"];
            }
            ViewBag.SummaryData = summaryData;
        }
        private void PopulateModalDataSources(SqlDataReader reader)//Helper Method
        {
            var modalDataSources = new ModalDataSourceViewModel();
            // Company name
            reader.NextResult();
            while (reader.Read())
            {
                modalDataSources.Companies.Add(
                    new SelectListItem
                    {
                        Value = reader["CompanyID"].ToString(),
                        Text = reader["CompanyName"].ToString()
                    });
            }
            // Supersession types
            reader.NextResult();
            while (reader.Read())
            {
                modalDataSources.SupersessionTypes.Add(
                    new SelectListItem
                    {
                        Value = reader["SupersessionTypeID"].ToString(),
                        Text = reader["TypeName"].ToString()
                    });
            }
            // Consumption codes
            reader.NextResult();
            while (reader.Read())
            {
                modalDataSources.ConsumptionCodes.Add(
                    new SelectListItem
                    {
                        Value = reader["ConsumptionCodeID"].ToString(),
                        Text = reader["CodeName"].ToString()
                    });
            }
            // Replacing codes
            reader.NextResult();
            while (reader.Read())
            {
                modalDataSources.ReplacingCodes.Add(
                    new SelectListItem
                    {
                        Value = reader["ReplacingCodeID"].ToString(),
                        Text = reader["CodeName"].ToString()
                    });
            }
            ViewBag.ModalDataSources = modalDataSources;
        }
        private void PopulateRulesAndPagination(SqlDataReader reader, int currentPage, int pageSize)//Helper Method
        {
            reader.NextResult();
            var rulesList = new List<SupersessionRuleViewModel>();
            var rulesDictionary = new Dictionary<int, SupersessionRuleViewModel>();
            var pagination = new PaginationViewModel { CurrentPage = currentPage, PageSize = pageSize };

            while (reader.Read())
            {
                int ruleId = (int)reader["RuleID"];
                if (!rulesDictionary.ContainsKey(ruleId))
                {
                    var rule = new SupersessionRuleViewModel
                    {
                        RuleID = ruleId,
                        CompanyName = reader["CompanyName"].ToString(),
                        SupersessionType = reader["SupersessionType"].ToString(),
                        ConsumptionCode = reader["ConsumptionCode"].ToString(),
                        ReplacingCode = reader["ReplacingCode"].ToString(),
                        EffectiveDate = reader["EffectiveDate"].ToString(),
                        IsActive = (bool)reader["IsActive"],
                        Remarks = reader["Remarks"].ToString()
                    };
                    rulesDictionary.Add(ruleId, rule);
                    rulesList.Add(rule);

                    if (pagination.TotalRecords == 0)
                    {
                        pagination.TotalRecords = (int)reader["TotalRecords"];
                    }
                }

                if (reader["PartID"] != DBNull.Value)
                {
                    var part = new PartViewModel
                    {
                        PartID = (int)reader["PartID"],
                        Prefix = reader["Prefix"].ToString(),
                        PartNumber = reader["PartNumber"].ToString(),
                        Description = reader["Description"].ToString(),
                        Quantity = (decimal)reader["Quantity"]
                    };

                    if (reader["PartRole"].ToString() == "O")
                    {
                        rulesDictionary[ruleId].OriginalParts.Add(part);
                    }
                    else
                    {
                        rulesDictionary[ruleId].SupersedingParts.Add(part);
                    }
                }
            }
            ViewBag.Rules = rulesList;
            ViewBag.Pagination = pagination;
        }
    }

}

public class SummaryDataViewModel // values for summar cards
{
    public int TotalRules { get; set; }
    public int ActiveRules { get; set; }
    public int OneToOneCount { get; set; }
    public int OneToManyCount { get; set; }
}
public class SupersessionRuleViewModel // values for Supersession 
{
    public int RuleID { get; set; }
    public string CompanyName { get; set; }
    public string SupersessionType { get; set; }
    public string ConsumptionCode { get; set; }
    public string ReplacingCode { get; set; }
    public string EffectiveDate { get; set; }
    public bool IsActive { get; set; }
    public string Remarks { get; set; }
    public List<PartViewModel> OriginalParts { get; set; } = new List<PartViewModel>();
    public List<PartViewModel> SupersedingParts { get; set; } = new List<PartViewModel>();
}
public class AddSupersessionViewModel // values to be stored while we add supersession 
{
    public int CompanyID { get; set; }
    public DateTime EffectiveDate { get; set; }
    public int SupersessionTypeID { get; set; }
    public int ConsumptionCodeID { get; set; }
    public int? ReplacingCodeID { get; set; }
    public string Remarks { get; set; }
    public bool IsActive { get; set; }
    public List<PartInputModel> OriginalParts { get; set; }
    public List<PartInputModel> SupersedingParts { get; set; }
}
public class UpdateSupersessionViewModal // values to be stored while we edit supersession 
{
    public int RuleID { get; set; }
    //public string CompanyID { get; set; }
    public string EffectiveDate { get; set; }
    public int SupersessionTypeID { get; set; }
    public int ConsumptionCodeID { get; set; }
    public int? ReplacingCodeID { get; set; }
    public string Remarks { get; set; }
    public bool IsActive { get; set; }
    public List<PartInputModel> OriginalParts { get; set; }
    public List<PartInputModel> SupersedingParts { get; set; }

}
public class PartInputModel // Values for parts while add/edit supersession
{
    public int PartID { get; set; }
    public decimal Quantity { get; set; }
}
public class PartViewModel //Values to be stored to display parts details 
{
    public int PartID { get; set; }
    public string Prefix { get; set; }
    public string PartNumber { get; set; }
    public string Description { get; set; }
    public decimal Quantity { get; set; }
}
public class PaginationViewModel // Values that store pagination information
{
    public int TotalRecords { get; set; }
    public int CurrentPage { get; set; }
    public int PageSize { get; set; }
    public int TotalPages => PageSize > 0 ? (int)Math.Ceiling((double)TotalRecords / PageSize) : 0;
}
public class ModalDataSourceViewModel //Values for Dropdown used in the Application 
{
    public List<SelectListItem> Companies { get; set; } = new List<SelectListItem>();
    public List<SelectListItem> SupersessionTypes { get; set; } = new List<SelectListItem>();
    public List<SelectListItem> ConsumptionCodes { get; set; } = new List<SelectListItem>();
    public List<SelectListItem> ReplacingCodes { get; set; } = new List<SelectListItem>();
}
public class FilteredResultViewModel //Calls both SupersessionRuleViewModal and PaginationViewModal to hold values for Filtered Supersession
{
    public List<SupersessionRuleViewModel> Rules { get; set; }
    public PaginationViewModel Pagination { get; set; }
}