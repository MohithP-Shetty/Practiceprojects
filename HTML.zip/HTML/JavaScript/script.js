//var Number1 = 20
//const Number2 = 30
//let Number3 = 40
// ===================================================================================
// Method 1: ES6 Class
// ===================================================================================
// Introduced in ES6 (2015), classes are "syntactic sugar" over constructor functions.
// They provide a much cleaner and more familiar syntax for creating object blueprints.
// This is the modern, recommended approach.
//console.log("\n--- Method 1: ES6 Class ---");

//class PersonClass {
//    constructor(FirstName, LastName, Age) {
//        this.FirstName = FirstName;
//        this.LastName = LastName;
//        this.Age = Age;
//    }
//    getFullName() {
//        return `${this.FirstName} ${this.LastName}`;
//    }
//    greet() {
//        console.log(`Greetings!my Name is ${this.getFullName()}.`);
//    }
//    static getDefination() {
//        return "this is a class for creating Person Object.";
//    }
//}

//const Person1 = new PersonClass("Mohith", "P Shetty", 23);
//const Person2 = new PersonClass("John", "doe", 40);

//console.log("Person 1 Full Name:", Person1.getFullName());
//Person1.greet();

//console.log("Person 2 Full Name:", Person2.getFullName());
//Person2.greet();

// ===================================================================================
// Method 2: Constructor Function
// ===================================================================================
// This is the traditional "blueprint" method in JavaScript before classes were introduced.
// It's a function that initializes new objects. The 'new' keyword is used to create an instance.
//console.log("\n--- Method 2: Constructor Function ---");

//function Person(firstname, lastname, age) {
//    this.firstname = firstname;
//    this.lastname = lastname;
//    this.age = age;
//}
//Person.prototype.getfullname = function () {
//    return this.firstname + " " + this.lastname;
//};

//Person.prototype.greet = () => {
//    console.log(`Greetings!my Name is ${this.getfullname()}.`);
//};

//const Person3 = new PersonClass("Mohith", "P Shetty", 23);
//const Person4 = new PersonClass("John", "doe", 40);

//console.log("Person 1 Full Name:", Person3.getFullName());
//Person3.greet();

//console.log("Person 2 Full Name:", Person4.getFullName());
//Person4.greet();

// ===================================================================================
// Event listeners
// ===================================================================================
//const grandparent1 = document.querySelector(".grandparent")
//const parent = document.querySelector(".parent")
//const child = document.querySelector(".child")
//function handelgrandparent(event) {
//    console.log(event)
//    const clicked = event.target;
//    if (clicked.classList.contains('c1')) {
//        clicked.classList.remove('c1');
//        clicked.classList.add('c2');
//    } else {
//        clicked.classList.remove('c2');
//        clicked.classList.add('c1');
//    }
//    //grandparent1.removeEventListener("click", handelgrandparent);
//}
//grandparent1.addEventListener("click", handelgrandparent, { capture: true });

//parent.addEventListener("mouseleave", e => {
//    console.log(e)
//}, { once: true });
//child.addEventListener("mouseout", e => {
//    console.log(e)
//});
//document.addEventListener("click", e => {
//    console.log(e)
//});

// ===================================================================================
// Promise
// ===================================================================================
//let p = new Promise((resolve, reject) => {
//    let a = 1 + 2
//    if (a == 2) {
//        resolve("Sucesses")
//    }
//    else {
//        reject("Failed")
//    }
//});

//p.then((message) => {
//    console.log("this is in the then : " + message);
//}).catch((message) => {
//    console.log("this is in the catch : " + message);
//})

//Promise can be used to replace callbacks since they are clean and readeable also we can avoide callback hell
const userLeft = false
const userHavingTea = true

//function userWorkCallBack(callback, errorCallback) {
//    if (userLeft) {
//        errorCallback({
//            name: 'User Left',
//            message: ':('
//        })
//    } else if (userHavingTea) {
//        errorCallback({
//            name: 'User is Having Tea\n',
//            message: 'Tea break is 15min'
//        })
//    } else {
//        callback('User is working')
//    }
//};
//userWorkCallBack((message) => {
//    console.log('Success : ' + message)
//}, (error) => {
//    console.log(error.name + error.message)
//})
////using Promise for the
function userWorkPromise() {
    return new Promise((resolve, reject) => {
        if (userLeft) {
            reject({
                name: 'User Left',
                message: ':('
            })
        } else if (userHavingTea) {
            reject({
                name: 'User is Having Tea\n',
                message: 'Tea break is 15min'
            })
        } else {
            resolve('User is working')
        }
    })

};

userWorkPromise().then((message) => {
    console.log('Success : ' + message)
}).catch((error) => {
    console.log(error.name + error.message)
});