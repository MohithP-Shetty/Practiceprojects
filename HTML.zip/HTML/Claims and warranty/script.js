document.addEventListener('DOMContentLoaded', function() {
  // --- CACHED DOM ELEMENTS ---
  const themeToggle = document.getElementById('theme-toggle');
  const menuToggle = document.getElementById('menu-toggle');
  const sideNav = document.getElementById('side-nav');
  const collapseNavBtn = document.getElementById('collapse-nav');
  const mainContent = document.querySelector('.main-content');
  
  const companyChartCtx = document.getElementById('company-chart');
  const trendChartCtx = document.getElementById('trend-chart');
  const companySearchInput = document.getElementById('company-search');
  const companyDropdown = document.getElementById('company-dropdown');
  
  const newClaimBtn = document.getElementById('new-claim-btn');
  const newClaimModal = document.getElementById('new-claim-modal');
  const closeModalBtns = document.querySelectorAll('#new-claim-modal .close-modal'); // More specific
  
  const addJobBtn = document.getElementById('add-job-btn');
  const jobsContainer = document.getElementById('jobs-container');
  const totalJobAmountElement = document.getElementById('total-job-amount');

  const uploadBtn = document.getElementById('upload-btn');
  const fileUploadInput = document.getElementById('file-upload');
  const fileUploadInfo = document.getElementById('file-upload-info');
  const attachmentsContainer = document.getElementById('attachments-container');

  const claimsCardsContainer = document.getElementById('claims-cards-container');
  const claimsSearchInput = document.getElementById('claims-search-input');
  const claimsSectionFooter = document.getElementById('claims-section-footer');
  const viewAllClaimsBtn = document.getElementById('view-all-claims-btn');

  // --- INITIALIZATION ---
  initTheme();
  if (typeof Chart !== 'undefined') {
    initCharts();
  } else {
    console.error('Chart.js not loaded yet. Charts will not initialize immediately.');
    // Fallback or delayed initialization can be handled here if Chart.js loads much later.
  }
  initSideNavigation();
  initPageNavigation();
  initNewClaimModal();
  initClaimActions(); // For search, pagination, view all of recent claims


  // --- THEME ---
  function initTheme() {
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    const currentTheme = localStorage.getItem('theme');

    if (currentTheme) {
      document.documentElement.setAttribute('data-theme', currentTheme);
      updateThemeIcon(currentTheme);
    } else {
      setTheme(prefersDarkScheme.matches ? 'dark' : 'light');
    }

    themeToggle.addEventListener('click', function() {
      const newTheme = document.documentElement.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
      setTheme(newTheme);
    });

    prefersDarkScheme.addEventListener('change', (e) => {
        if (!localStorage.getItem('theme')) { // Only if no explicit theme is set
            setTheme(e.matches ? 'dark' : 'light');
        }
    });

    function setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
        updateThemeIcon(theme);
        // If charts are initialized, update their grid colors
        if (window.companyChartInstance) window.companyChartInstance.update();
        if (window.trendChartInstance) window.trendChartInstance.update();
    }

    function updateThemeIcon(theme) {
      const icon = themeToggle.querySelector('.material-icons');
      icon.textContent = theme === 'light' ? 'dark_mode' : 'light_mode';
    }
  }

  // --- CHARTS ---
  function initCharts() {
    console.log('Chart.js confirmed loaded or initializing charts...');
    
    // Sample data for companies
    const companyData = {
      'Acme Corp': { approved: [15, 22, 18, 25, 30, 28], rejected: [5, 3, 7, 4, 2, 6] },
      'TechSolutions': { approved: [10, 15, 20, 18, 22, 25], rejected: [8, 5, 3, 6, 4, 2] },
      'Global Systems': { approved: [20, 18, 25, 30, 28, 35], rejected: [7, 9, 5, 3, 6, 4] },
      'Innovate Inc': { approved: [12, 18, 15, 20, 25, 22], rejected: [6, 4, 8, 5, 3, 7] },
      'DataTech': { approved: [8, 12, 18, 22, 20, 25], rejected: [4, 6, 3, 5, 8, 6] }
    };
    let selectedCompany = 'Acme Corp';

    if (companyChartCtx) {
      window.companyChartInstance = new Chart(companyChartCtx, { // Store instance globally for theme updates
        type: 'line',
        data: {
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
          datasets: [
            { label: 'Approved', data: companyData[selectedCompany].approved, borderColor: 'var(--status-approved)', backgroundColor: 'rgba(67, 160, 71, 0.1)', tension: 0.4, fill: true },
            { label: 'Rejected', data: companyData[selectedCompany].rejected, borderColor: 'var(--status-rejected)', backgroundColor: 'rgba(229, 57, 53, 0.1)', tension: 0.4, fill: true }
          ]
        },
        options: getChartOptions()
      });
      initCompanyDropdown(companyData, window.companyChartInstance);
    } else {
      console.error('Company chart canvas not found');
    }
    
    if (trendChartCtx) {
      window.trendChartInstance = new Chart(trendChartCtx, { // Store instance
        type: 'line',
        data: {
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
          datasets: [{ label: 'Claims', data: [12, 19, 15, 17, 22, 18], borderColor: 'var(--md-primary)', backgroundColor: 'rgba(0, 0, 0, 0.05)', tension: 0.4, fill: true }]
        },
        options: getChartOptions(false) // Legend false for this one
      });
    } else {
      console.error('Trend chart canvas not found');
    }
  }

  function getChartOptions(showLegend = true) {
    return {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: showLegend,
          position: 'top',
          labels: { boxWidth: 12, font: { size: 10 } }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { font: { size: 10 }, color: () => getComputedStyle(document.documentElement).getPropertyValue('--md-on-surface-variant') },
          grid: { color: () => getComputedStyle(document.documentElement).getPropertyValue('--md-outline') }
        },
        x: {
          ticks: { font: { size: 10 }, color: () => getComputedStyle(document.documentElement).getPropertyValue('--md-on-surface-variant') },
          grid: { display: false }
        }
      }
    };
  }

  function initCompanyDropdown(companyData, chart) {
    const dropdownItems = companyDropdown.querySelectorAll('.dropdown-item');
    
    companySearchInput.addEventListener('focus', () => companyDropdown.classList.add('active'));
    companySearchInput.addEventListener('input', function() {
      const searchTerm = this.value.toLowerCase();
      dropdownItems.forEach(item => {
        item.style.display = item.getAttribute('data-company').toLowerCase().includes(searchTerm) ? '' : 'none';
      });
    });
    
    dropdownItems.forEach(item => {
      item.addEventListener('click', function() {
        const company = this.getAttribute('data-company');
        companySearchInput.value = company;
        dropdownItems.forEach(i => i.classList.remove('selected'));
        this.classList.add('selected');
        companyDropdown.classList.remove('active');
        updateCompanyChart(chart, company, companyData);
      });
    });
    
    document.addEventListener('click', function(e) {
      if (!companySearchInput.contains(e.target) && !companyDropdown.contains(e.target)) {
        companyDropdown.classList.remove('active');
      }
    });
    
    companySearchInput.value = 'Acme Corp'; // Set initial
    if(dropdownItems.length > 0) dropdownItems[0].classList.add('selected');
  }

  function updateCompanyChart(chart, company, companyData) {
    if (companyData[company]) {
        chart.data.datasets[0].data = companyData[company].approved;
        chart.data.datasets[1].data = companyData[company].rejected;
        chart.update();
    }
  }

  // --- SIDE NAVIGATION ---
  function initSideNavigation() {
    menuToggle.addEventListener('click', () => sideNav.classList.toggle('open'));
    collapseNavBtn.addEventListener('click', () => {
      sideNav.classList.toggle('collapsed');
      mainContent.style.marginLeft = sideNav.classList.contains('collapsed') ? '72px' : '';
    });

    const menuItemsWithSubmenu = document.querySelectorAll('.side-nav .has-submenu');
    menuItemsWithSubmenu.forEach(item => {
      const link = item.querySelector('.nav-link');
      link.addEventListener('click', function(e) {
        if (item.classList.contains('collapsed') && !e.target.closest('.submenu')) return; // Prevent toggle if collapsed and not clicking submenu directly

        e.preventDefault();
        const currentlyExpanded = item.classList.contains('expanded');
        // Close all others
        menuItemsWithSubmenu.forEach(otherItem => otherItem.classList.remove('expanded'));
        // Toggle current
        if (!currentlyExpanded) {
            item.classList.add('expanded');
        }
      });
    });

    document.addEventListener('click', function(event) {
      if (!sideNav.contains(event.target) && !menuToggle.contains(event.target) && window.innerWidth <= 768) {
        sideNav.classList.remove('open');
      }
    });

    // Auto-expand active submenu
    const activeSubmenuItem = document.querySelector('.side-nav .submenu .active');
    if (activeSubmenuItem) {
      const parentItem = activeSubmenuItem.closest('.has-submenu');
      if (parentItem) parentItem.classList.add('expanded');
    }
  }

  // --- PAGE NAVIGATION ---
  function initPageNavigation() {
    const navLinks = document.querySelectorAll('.side-nav .nav-link[data-page]');
    const pages = document.querySelectorAll('.page-container .page');

    navLinks.forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        const targetPageId = this.getAttribute('data-page');
        
        document.querySelectorAll('.side-nav .nav-item').forEach(item => item.classList.remove('active'));
        document.querySelectorAll('.side-nav .nav-link').forEach(navLink => navLink.parentElement.classList.remove('active')); // For subitems
        
        this.closest('.nav-item').classList.add('active'); // Active on li
        if (this.closest('.submenu')) { // If it's a submenu item
             this.closest('.has-submenu').classList.add('active'); // Also active on parent category
        }

        pages.forEach(page => page.classList.remove('active'));
        const targetPage = document.getElementById(targetPageId);
        if (targetPage) targetPage.classList.add('active');
        
        if (window.innerWidth <= 768) sideNav.classList.remove('open'); // Close nav on mobile after click
      });
    });
  }

  // --- NEW CLAIM MODAL ---
  function initNewClaimModal() {
    newClaimBtn.addEventListener('click', () => {
      newClaimModal.classList.add('active');
      document.body.style.overflow = 'hidden';
    });

    closeModalBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        newClaimModal.classList.remove('active');
        document.body.style.overflow = '';
      });
    });

    newClaimModal.addEventListener('click', e => {
      if (e.target === newClaimModal) {
        newClaimModal.classList.remove('active');
        document.body.style.overflow = '';
      }
    });

    // Add Job (with event delegation for remove)
    addJobBtn.addEventListener('click', function() {
      const jobCardHTML = `
        <div class="job-card">
          <div class="job-card-header">
            <div class="job-id"><input type="text" placeholder="Work Order S/N"></div>
            <div class="job-actions">
              <button class="icon-button remove-job-btn"><span class="material-icons">delete</span></button>
            </div>
          </div>
          <div class="job-card-content">
            <div class="job-detail"><label>Date</label><input type="date"></div>
            <div class="job-detail"><label>Service Type</label><select><option>Repair</option><option>Maintenance</option><option>Installation</option><option>Replacement</option></select></div>
            <div class="job-detail"><label>Brand</label><input type="text" placeholder="Brand"></div>
            <div class="job-detail"><label>Model</label><input type="text" placeholder="Model"></div>
            <div class="job-detail"><label>Asset Type</label><input type="text" placeholder="Asset Type"></div>
            <div class="job-detail"><label>Serial Number</label><input type="text" placeholder="Serial Number"></div>
            <div class="job-detail"><label>Claimed Amount</label><input type="number" placeholder="0.00" class="job-amount"></div>
            <div class="job-detail"><label>Status</label><select class="job-status"><option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option></select></div>
          </div>
        </div>`;
      jobsContainer.insertAdjacentHTML('beforeend', jobCardHTML);
      updateTotalJobAmount(); // Update total when a new card (with 0 amount) is added
    });
    
    // Event delegation for removing job cards and updating total
    jobsContainer.addEventListener('click', function(event) {
      const removeBtn = event.target.closest('.remove-job-btn');
      if (removeBtn) {
        removeBtn.closest('.job-card').remove();
        updateTotalJobAmount();
      }
    });
    jobsContainer.addEventListener('input', function(event) {
        if (event.target.classList.contains('job-amount')) {
            updateTotalJobAmount();
        }
    });


    // File Upload (with event delegation for remove)
    uploadBtn.addEventListener('click', () => fileUploadInput.click());
    fileUploadInput.addEventListener('change', function() {
      if (this.files.length > 0) {
        fileUploadInfo.textContent = `${this.files.length} file(s) selected`;
        // Clear previous attachments in UI if you are re-selecting
        // attachmentsContainer.innerHTML = ''; // Uncomment if you want to replace files on new selection
        for (let i = 0; i < this.files.length; i++) {
          const file = this.files[i];
          const attachmentItemHTML = `
            <div class="attachment-item">
              <span class="material-icons attachment-icon">${getFileTypeIcon(file.name)}</span>
              <div class="attachment-details">
                <div class="attachment-name">${escapeHTML(file.name)}</div>
                <div class="attachment-size">${formatFileSize(file.size)}</div>
              </div>
              <div class="attachment-actions">
                <button class="icon-button remove-attachment-btn"><span class="material-icons">delete</span></button>
              </div>
            </div>`;
          attachmentsContainer.insertAdjacentHTML('beforeend', attachmentItemHTML);
        }
      } else {
        fileUploadInfo.textContent = 'No files selected';
      }
    });

    attachmentsContainer.addEventListener('click', function(event) {
        const removeBtn = event.target.closest('.remove-attachment-btn');
        if (removeBtn) {
            removeBtn.closest('.attachment-item').remove();
            const remainingAttachments = attachmentsContainer.querySelectorAll('.attachment-item').length;
            fileUploadInfo.textContent = remainingAttachments > 0 ? `${remainingAttachments} file(s) selected` : 'No files selected';
            if (remainingAttachments === 0) fileUploadInput.value = ''; // Clear file input
        }
    });
  }
  
  function updateTotalJobAmount() {
    const amountInputs = jobsContainer.querySelectorAll('.job-amount');
    let total = 0;
    amountInputs.forEach(input => total += parseFloat(input.value) || 0);
    if (totalJobAmountElement) totalJobAmountElement.textContent = `$${total.toFixed(2)}`;
  }

  function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  function getFileTypeIcon(filename) {
    const extension = filename.split('.').pop().toLowerCase();
    const iconMap = { pdf: 'picture_as_pdf', doc: 'description', docx: 'description', xls: 'table_chart', xlsx: 'table_chart', jpg: 'image', jpeg: 'image', png: 'image', gif: 'image' };
    return iconMap[extension] || 'insert_drive_file';
  }
  function escapeHTML(str) {
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(str));
    return div.innerHTML;
  }


  // --- RECENT CLAIMS ACTIONS (Search, Pagination, View All, Card Click) ---
  function initClaimActions() {
    const cardsPerPage = 8;
    let currentPage = 1;
    let allClaimCards = Array.from(claimsCardsContainer.querySelectorAll('.claim-card')); // Get all cards once

    function displayCards() {
        const searchTerm = claimsSearchInput.value.toLowerCase();
        const filteredCards = allClaimCards.filter(card => {
            const claimId = card.querySelector('.claim-id')?.textContent.toLowerCase() || '';
            const claimNote = card.querySelector('.claim-note')?.textContent.toLowerCase() || '';
            return claimId.includes(searchTerm) || claimNote.includes(searchTerm);
        });

        // Update pagination based on filtered cards
        const totalCards = filteredCards.length;
        const totalPages = Math.ceil(totalCards / cardsPerPage);

        // Show/hide footer based on search
        claimsSectionFooter.style.display = searchTerm.length > 0 ? 'none' : 'flex';

        const startIndex = (currentPage - 1) * cardsPerPage;
        const endIndex = currentPage * cardsPerPage;

        // Display all cards in the DOM but control visibility via a class or style
        allClaimCards.forEach(card => card.style.display = 'none'); // Hide all initially

        filteredCards.forEach((card, index) => {
            if (searchTerm.length > 0) { // If searching, show all matched
                card.style.display = ''; 
            } else { // If not searching, paginate
                 if (index >= startIndex && index < endIndex) {
                    card.style.display = '';
                 }
            }
        });
        
        if (searchTerm.length === 0) { // Only update pagination UI if not searching
            updatePaginationUI(totalCards, totalPages);
        }
    }
    
    function updatePaginationUI(totalCards, totalPages) {
        const pageInfoEl = claimsSectionFooter.querySelector('.page-info');
        const paginationButtonsContainer = claimsSectionFooter.querySelector('.pagination');
        const prevButton = paginationButtonsContainer.querySelector('#claims-prev-page');
        const nextButton = paginationButtonsContainer.querySelector('#claims-next-page');

        if (totalCards === 0) {
            pageInfoEl.textContent = "No claims found";
            paginationButtonsContainer.style.display = 'none'; // Hide pagination if no cards
            return;
        }
        paginationButtonsContainer.style.display = 'flex';


        const startItem = (currentPage - 1) * cardsPerPage + 1;
        const endItem = Math.min(currentPage * cardsPerPage, totalCards);
        pageInfoEl.textContent = `${startItem}-${endItem} of ${totalCards}`;

        prevButton.disabled = currentPage === 1;
        nextButton.disabled = currentPage === totalPages || totalPages === 0;

        // Dynamic page buttons (simple example: just show current and next if available)
        const existingPageButtons = paginationButtonsContainer.querySelectorAll('.page-button');
        existingPageButtons.forEach(btn => btn.remove());

        for (let i = 1; i <= totalPages; i++) {
            if (totalPages > 1 && (i === currentPage || (totalPages <= 5) || (i === 1 || i === totalPages || (i >= currentPage -1 && i <= currentPage + 1)))) {
                 const pageButton = document.createElement('button');
                 pageButton.classList.add('page-button');
                 pageButton.textContent = i;
                 if (i === currentPage) pageButton.classList.add('active');
                 pageButton.addEventListener('click', () => {
                     currentPage = i;
                     displayCards();
                 });
                 nextButton.insertAdjacentElement('beforebegin', pageButton);
            } else if (totalPages > 5 && (i === currentPage - 2 || i === currentPage + 2) ) {
                const ellipsis = document.createElement('span');
                ellipsis.textContent = "...";
                ellipsis.style.padding = "0 8px";
                ellipsis.style.alignSelf = "center";
                nextButton.insertAdjacentElement('beforebegin', ellipsis);
            }
        }
    }

    claimsSearchInput.addEventListener('input', () => {
        currentPage = 1; // Reset to first page on new search
        displayCards();
    });

    claimsSectionFooter.addEventListener('click', (event) => {
        const target = event.target;
        if (target.closest('#claims-prev-page') && currentPage > 1) {
            currentPage--;
            displayCards();
        } else if (target.closest('#claims-next-page')) {
            const totalPages = Math.ceil(allClaimCards.filter(card => card.style.display !== 'none' || claimsSearchInput.value === '').length / cardsPerPage); // Recalc for safety
            if (currentPage < totalPages) {
                 currentPage++;
                 displayCards();
            }
        }
    });
    
    // Event delegation for claim card clicks
    if (claimsCardsContainer) {
        claimsCardsContainer.addEventListener('click', function(event) {
            const card = event.target.closest('.claim-card');
            if (card) {
                card.classList.add('clicked'); // For animation
                
                const claimId = card.querySelector('.claim-id')?.textContent || 'N/A';
                const claimDate = card.querySelector('.claim-date')?.textContent || 'N/A';
                const claimNote = card.querySelector('.claim-note')?.textContent || 'N/A';
                const claimedAmountEl = card.querySelector('.claim-amounts .claim-amount:first-child');
                const approvedAmountEl = card.querySelector('.claim-amounts .claim-amount:last-child');

                const claimedAmount = claimedAmountEl ? claimedAmountEl.textContent.trim().split('\n').pop().trim() : 'N/A';
                const approvedAmount = approvedAmountEl ? approvedAmountEl.textContent.trim().split('\n').pop().trim() : 'N/A';
                
                let status = "Pending"; // Default
                const statusIndicator = card.querySelector('.claim-status-indicator');
                if (statusIndicator) {
                    if (statusIndicator.classList.contains('approved')) status = "Approved";
                    else if (statusIndicator.classList.contains('rejected')) status = "Rejected";
                }
                
                console.log(`View details for claim: ${claimId}`);
                showClaimDetailsModal(claimId, claimDate, claimNote, claimedAmount, approvedAmount, status);
                
                setTimeout(() => card.classList.remove('clicked'), 300);
            }
        });
    }

    if (viewAllClaimsBtn) {
        viewAllClaimsBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            console.log('View all claims clicked');
            // Implement navigation or full list display logic here
        });
    }
    
    displayCards(); // Initial display
  }


  // --- CLAIM DETAILS MODAL (View Only) ---
  function showClaimDetailsModal(id, date, note, claimed, approved, status) {
    let modal = document.getElementById('claim-details-modal');
    if (!modal) { // Create modal if it doesn't exist
      modal = document.createElement('div');
      modal.id = 'claim-details-modal';
      modal.className = 'modal';
      // Using insertAdjacentHTML for creating the modal structure once.
      modal.insertAdjacentHTML('beforeend', `
        <div class="modal-content">
          <div class="modal-header">
            <h2>Claim Details</h2>
            <button class="icon-button close-modal-details"><span class="material-icons">close</span></button>
          </div>
          <div class="modal-body">
            <div class="form-section">
              <h3>Claim Information</h3>
              <div class="form-row">
                <div class="form-group"><label>Claim S/N</label><input type="text" id="modal-claim-id" readonly></div>
                <div class="form-group"><label>Date</label><input type="text" id="modal-claim-date" readonly></div>
                <div class="form-group"><label>Note Reference</label><input type="text" id="modal-claim-note" readonly></div>
              </div>
              <div class="form-row">
                <div class="form-group"><label>Claimed Amount</label><input type="text" id="modal-claimed-amount" readonly></div>
                <div class="form-group"><label>Approved Amount</label><input type="text" id="modal-approved-amount" readonly></div>
                <div class="form-group"><label>Status</label><input type="text" id="modal-details-status" readonly></div>
              </div>
            </div>
            <div class="form-section">
              <div class="section-header"><h3>Job Details</h3></div>
              <div class="jobs-cards-container" id="modal-jobs-container">
                <div class="job-card">
                    <div class="job-card-header">
                        <div class="job-id">WO-SAMPLE-001</div>
                        <div class="job-status-indicator approved"></div>
                    </div>
                    <div class="job-card-content">
                        <div class="job-detail"><span class="label">Date:</span> <span class="value">01 Jan 2023</span></div>
                        <div class="job-detail"><span class="label">Service:</span> <span class="value">Repair</span></div>
                        <div class="job-detail"><span class="label">Brand/Model:</span> <span class="value">Sample Brand Model S</span></div>
                        <div class="job-detail"><span class="label">Amount:</span> <span class="value">$100.00</span></div>
                    </div>
                </div>
              </div>
            </div>
            <div class="form-section">
              <div class="section-header"><h3>Attachments</h3></div>
              <div class="table-container">
                <table class="data-table" id="modal-attachments-table">
                  <thead><tr><th>File Name</th><th>Description</th><th>Uploaded By</th><th>Date</th></tr></thead>
                  <tbody><tr><td colspan="4"><i>No attachments linked or sample data.</i></td></tr></tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="secondary-button close-modal-details">Close</button>
            <button class="primary-button" id="edit-claim-btn-from-details">Edit Claim</button>
          </div>
        </div>
      `);
      document.body.appendChild(modal);

      // Add event listeners for the newly created modal's close buttons
      modal.addEventListener('click', (e) => {
        if (e.target.classList.contains('close-modal-details') || e.target.closest('.close-modal-details')) {
          modal.classList.remove('active');
          document.body.style.overflow = '';
        }
        if (e.target.id === 'edit-claim-btn-from-details') {
            console.log(`Edit claim: ${document.getElementById('modal-claim-id').value}`);
            modal.classList.remove('active');
            document.body.style.overflow = '';
            // Potentially open the newClaimModal prefilled or a dedicated edit modal
        }
        if (e.target === modal) { // Click outside content
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
      });
    }

    // Populate modal fields
    modal.querySelector('#modal-claim-id').value = id;
    modal.querySelector('#modal-claim-date').value = date;
    modal.querySelector('#modal-claim-note').value = note;
    modal.querySelector('#modal-claimed-amount').value = claimed;
    modal.querySelector('#modal-approved-amount').value = approved;
    const statusInput = modal.querySelector('#modal-details-status');
    statusInput.value = status;
    statusInput.className = ''; // Clear previous status classes
    statusInput.classList.add(status.toLowerCase());

    // TODO: Populate Job Details & Attachments for the specific claim (fetch or use passed data)
    const modalJobsContainer = modal.querySelector('#modal-jobs-container');
    modalJobsContainer.innerHTML = '<p><i>Job details for this claim would be loaded here.</i></p>'; // Placeholder
    const modalAttachmentsTableBody = modal.querySelector('#modal-attachments-table tbody');
    modalAttachmentsTableBody.innerHTML = '<tr><td colspan="4"><i>Attachments for this claim would be listed here.</i></td></tr>'; // Placeholder


    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  // --- GENERAL RIPPLE EFFECT FOR BUTTONS ---
  // Needs to be re-applied or use delegation if buttons are added dynamically post-load
  // For simplicity, this applies to buttons present at load time.
  document.querySelectorAll('button').forEach(button => {
    button.addEventListener('click', function(e) {
      // Only proceed if the button doesn't already have a ripple or is not disabled
      if (this.querySelector('.ripple') || this.disabled) return;

      const rect = e.target.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const ripple = document.createElement('span');
      ripple.classList.add('ripple');
      ripple.style.left = `${x}px`;
      ripple.style.top = `${y}px`;
      
      this.appendChild(ripple);
      setTimeout(() => ripple.remove(), 600);
    });
  });

  // --- WINDOW RESIZE HANDLER ---
  window.addEventListener('resize', function() {
    if (window.innerWidth > 768) {
      sideNav.classList.remove('open'); // Close mobile nav if screen becomes larger
      // Reset main content margin if sideNav was collapsed and then screen resized
      if (!sideNav.classList.contains('collapsed')) {
        mainContent.style.marginLeft = '';
      } else {
        mainContent.style.marginLeft = '72px';
      }
    }
  });

}); // End DOMContentLoaded