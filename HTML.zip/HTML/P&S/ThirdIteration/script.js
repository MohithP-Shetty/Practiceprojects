// --- Mock Data for Dropdowns ---
const mockTenants = [ { name: "Global Corp", value: "T01" }, { name: "Innovate Solutions", value: "T02" }, { name: "Alpha Services", value: "T03"} ];
const mockCountries = [ { name: "US (United States)", value: "US" }, { name: "CA (Canada)", value: "CA" }, { name: "GB (United Kingdom)", value: "GB"}, { name: "IN (India)", value: "IN"}];
const mockBranches = [ { name: "North America HQ", value: "B001" }, { name: "Europe Division", value: "EUD" }, { name: "Asia Pacific Office", value: "APAC"} ];
const mockObjects = [
    { name: "Sales Invoice", value: "SAL_INV", defaultShort: "SINV" }, { name: "Sales Return", value: "SAL_RET", defaultShort: "SRET" },
    { name: "Purchase Order", value: "PUR_ORD", defaultShort: "PORD" }, { name: "Inventory Transfer", value: "INV_TRN", defaultShort: "ITRF" },
    { name: "Service Order", value: "SVC_ORD", defaultShort: "SORD" }, { name: "Work Order", value: "WRK_ORD", defaultShort: "WORD" },
    { name: "Warranty Claim", value: "WAR_CLM", defaultShort: "WCLM" }, { name: "RMA Request", value: "RMA_REQ", defaultShort: "RMAR" }, 
    { name: "Part Request", value: "PRT_REQ", defaultShort: "PREQ" }, { name: "Support Ticket", value: "SUP_TCK", defaultShort: "STCK" },
    { name: "Field Service Report", value: "FSR_REP", defaultShort: "FSR" }, { name: "Maintenance Log", value: "MNT_LOG", defaultShort: "MLOG" },
    { name: "Rental Agreement", value: "REN_AGR", defaultShort: "RAGR" }, { name: "Usage Log", value: "USG_LOG", defaultShort: "ULOG" },
    { name: "Inspection Report", value: "INS_REP", defaultShort: "IREP"}, { name: "Calibration Record", value: "CAL_REC", defaultShort: "CREC"}
];
const mockFinancialYears = [ { name: "2023-2024", value: "2024" }, { name: "2024-2025", value: "2025" }, { name: "FY22", value: "2022" } ];
const mockTimestampFormats = [ {name: "YYYYMMDDHHmmss (20240115103000)", value:"YYYYMMDDHHmmss"}, {name:"Epoch Milliseconds (1705314600000)", value:"epoch_ms"}, {name:"YYMMDD (240115)", value:"YYMMDD"}];
const mockUniquenessTypes = [ {name:"Incrementing Number", value:"increment"}, {name:"Random Alphanumeric", value:"random_alpha_num"}, {name:"Short UUID", value:"uuid_short"}];
const mockDelimiters = [
    {name:"-", value:"-"}, {name:"_", value:"_"},
    {name:".", value:"."}, {name:"/", value:"/"},
    {name:"None (No delimiter)", value:""}
];


let definitions = [];
let currentEditingDefinitionId = null;
let currentPage = 1;
const recordsPerPage = 10; // Keep this at 10 to demonstrate pagination with 25+ records


function navigateTo(sectionId, clickedElement) { 
    $('.app-sidenav ul li').removeClass('active'); $(clickedElement).parent('li').addClass('active');
    $('.content-section').removeClass('active'); $('#' + sectionId + 'Content').addClass('active');
    if (sectionId === 'prefixSuffix') {
        if (currentEditingDefinitionId) { $('#definitionEditorPane').addClass('active').show(); $('#welcomePane').hide(); }
        else { $('#definitionEditorPane').hide(); $('#welcomePane').show(); }
        currentPage = 1; renderDefinitionsTable();
    }
}

function showDefinitionEditor(defId) { 
    currentEditingDefinitionId = defId; $('#definitionEditorPane').addClass('active').show(); $('#welcomePane').hide(); renderDefinitionsTable();
    const form = $('#definitionForm')[0]; form.reset();
    if (defId) {
        const def = definitions.find(c => c.id === defId);
        if (def) {
            $('#editorTitle').text('Edit Definition'); $('#editingDefinitionId').val(def.id); $('#definitionName').val(def.name);
            $('#tenantNameInput').val(def.tenantNameInput); $('#tenantIdPrefixVal').val(def.tenantIdPrefixVal);
            $('#countryCodeInput').val(def.countryCodeInput); $('#countryCodeVal').val(def.countryCodeVal);
            $('#branchNameInput').val(def.branchNameInput); $('#branchIdPrefixVal').val(def.branchIdPrefixVal);
            $('#objectIdentifierInput').val(def.objectIdentifierInput); $('#objectIdentifierVal').val(def.objectIdentifierVal);
            $('#objectShortFormInput').val(def.objectShortFormInput);
            $('#includeTimestamp').prop('checked', def.includeTimestamp);
            $('#timestampFormatInput').val(def.timestampFormatInput); $('#timestampFormatVal').val(def.timestampFormatVal);
            $('#timestampFormatContainer').toggle(def.includeTimestamp);
            $('#financialYearInput').val(def.financialYearInput); $('#financialYearValue').val(def.financialYearValue);
            $('#uniquenessTypeInput').val(def.uniquenessTypeInput); $('#uniquenessTypeVal').val(def.uniquenessTypeVal);
            handleUniquenessTypeChange(def.uniquenessTypeVal);
            if (def.uniquenessTypeVal === 'increment') { $('#uniqueStartNumber').val(def.uniqueStartNumber); $('#paddingLength').val(def.paddingLength); }
            else if (def.uniquenessTypeVal && def.uniquenessTypeVal.startsWith('random')) { $('#randomLength').val(def.randomLength || 8); }
            $('#idDelimiterInput').val(def.idDelimiterInput); $('#idDelimiterVal').val(def.idDelimiterVal);
        }
    } else {
        $('#editorTitle').text('Create New Definition'); $('#editingDefinitionId').val('');
        $('#includeTimestamp').prop('checked', true); $('#timestampFormatContainer').show();
        const tFormat = mockTimestampFormats[0]; if(tFormat){ $('#timestampFormatInput').val(tFormat.name); $('#timestampFormatVal').val(tFormat.value); }
        const uType = mockUniquenessTypes[0]; if(uType){ $('#uniquenessTypeInput').val(uType.name); $('#uniquenessTypeVal').val(uType.value); }
        handleUniquenessTypeChange($('#uniquenessTypeVal').val());
        const delim = mockDelimiters[0]; if(delim){ $('#idDelimiterInput').val(delim.name); $('#idDelimiterVal').val(delim.value); }
        const fy = mockFinancialYears[0]; if(fy){ $('#financialYearInput').val(fy.name); $('#financialYearValue').val(fy.value); }
        const country = mockCountries[0]; if(country){ $('#countryCodeInput').val(country.name); $('#countryCodeVal').val(country.value); }
    }
    generatePreview();
    const prefixTabLink = $('#definitionEditorPane .mui-tabs__bar a[data-mui-controls="pane-prefix"]');
    if (prefixTabLink.length) { mui.tabs.activate('pane-prefix'); }
    else { mui.tabs.activate($('#definitionEditorPane .mui-tabs__bar li:first-child a').data('mui-controls')); }
}
function cancelEdit() { 
    $('#definitionEditorPane').removeClass('active').hide(); $('#welcomePane').show(); currentEditingDefinitionId = null; renderDefinitionsTable();
}
function saveDefinition() { 
    const name = $('#definitionName').val(); if (!name) { alert("Definition Name is required."); return; }
    const objectVal = $('#objectIdentifierVal').val(); if(!objectVal) { alert("Object must be selected."); return; }
    const objectShort = $('#objectShortFormInput').val(); if(!objectShort) { alert("Object Short Form must be provided."); return; }
    const defData = {
        id: currentEditingDefinitionId || 'cfg' + (definitions.length + 1) + Date.now(), name: name,
        tenantNameInput: $('#tenantNameInput').val(), tenantIdPrefixVal: $('#tenantIdPrefixVal').val(),
        countryCodeInput: $('#countryCodeInput').val(), countryCodeVal: $('#countryCodeVal').val(),
        branchNameInput: $('#branchNameInput').val(), branchIdPrefixVal: $('#branchIdPrefixVal').val(),
        objectIdentifierInput: $('#objectIdentifierInput').val(), objectIdentifierVal: objectVal, objectShortFormInput: objectShort,
        includeTimestamp: $('#includeTimestamp').is(':checked'),
        timestampFormatInput: $('#timestampFormatInput').val(), timestampFormatVal: $('#timestampFormatVal').val(),
        financialYearInput: $('#financialYearInput').val(), financialYearValue: $('#financialYearValue').val(),
        uniquenessTypeInput: $('#uniquenessTypeInput').val(), uniquenessTypeVal: $('#uniquenessTypeVal').val(),
        idDelimiterInput: $('#idDelimiterInput').val(), idDelimiterVal: $('#idDelimiterVal').val()
    };
    if (defData.uniquenessTypeVal === 'increment') { defData.uniqueStartNumber = parseInt($('#uniqueStartNumber').val()) || 1; defData.paddingLength = parseInt($('#paddingLength').val()) || 5; }
    else if (defData.uniquenessTypeVal && defData.uniquenessTypeVal.startsWith('random')) { defData.randomLength = parseInt($('#randomLength').val()) || 8; }
    if (currentEditingDefinitionId) { const index = definitions.findIndex(c => c.id === currentEditingDefinitionId); definitions[index] = defData; }
    else { definitions.push(defData); }
    currentEditingDefinitionId = null; renderDefinitionsTable(); cancelEdit();
}
function editDefinition(defId) { showDefinitionEditor(defId); }
function deleteDefinition(defId) { 
    if (!confirm('Are you sure you want to delete this definition?')) return;
    definitions = definitions.filter(c => c.id !== defId);
    if (currentEditingDefinitionId === defId) { cancelEdit(); }
    const totalFilteredRecordsAfterDelete = getFilteredDefinitions().length;
    const totalPagesAfterDelete = Math.ceil(totalFilteredRecordsAfterDelete / recordsPerPage);
    if (currentPage > totalPagesAfterDelete && totalPagesAfterDelete > 0) { currentPage = totalPagesAfterDelete; }
    else if (currentPage > 1 && getFilteredDefinitionsStartingAtPage(currentPage).length === 0 && totalFilteredRecordsAfterDelete > 0) { currentPage--; }
    else if (totalFilteredRecordsAfterDelete === 0) { currentPage = 1; }
    renderDefinitionsTable();
}

function getFilteredDefinitions() { 
    const filterTenant = $('#tenantFilterValue').val(); const filterBranch = $('#branchFilterValue').val(); const filterObject = $('#objectFilterValue').val();
    let filtered = definitions;
    if (filterTenant) { filtered = filtered.filter(d => d.tenantIdPrefixVal === filterTenant); }
    if (filterBranch) { filtered = filtered.filter(d => d.branchIdPrefixVal === filterBranch); }
    if (filterObject) { filtered = filtered.filter(d => d.objectIdentifierVal === filterObject); }
    return filtered;
}
function getFilteredDefinitionsStartingAtPage(pageNumber) { 
     const filtered = getFilteredDefinitions(); const startIndex = (pageNumber - 1) * recordsPerPage;
     return filtered.slice(startIndex, startIndex + recordsPerPage);
}
function renderDefinitionsTable() { 
    const tbody = $('#definitionsTableBody'); tbody.empty();
    const filteredDefsAll = getFilteredDefinitions(); const totalFilteredRecords = filteredDefsAll.length;
    
    // Adjust current page if it's out of bounds after filtering or deletion
    const totalPages = Math.ceil(totalFilteredRecords / recordsPerPage);
    if (currentPage > totalPages && totalPages > 0) {
        currentPage = totalPages;
    } else if (currentPage === 0 && totalPages > 0) { // Should not happen but as a safe guard
        currentPage = 1;
    }


    const startIndex = (currentPage - 1) * recordsPerPage; 
    const endIndex = startIndex + recordsPerPage;
    const defsToShowOnPage = filteredDefsAll.slice(startIndex, endIndex);
    
    if (defsToShowOnPage.length === 0 && !$('#definitionListContentContainer').hasClass('collapsed')) {
         tbody.append('<tr><td colspan="6" style="text-align:center; padding: 20px; color:#777;">No definitions found for current filter.</td></tr>');
    } else if (defsToShowOnPage.length > 0) {
        defsToShowOnPage.forEach(def => {
            const { prefix, midfix, suffix } = getExampleParts(def);
            const selectedClass = currentEditingDefinitionId === def.id ? 'mui--is-selected' : '';
            const row = $(`<tr data-def-id="${def.id}" class="${selectedClass}"><td><i class="material-icons action-buttons" onclick="editDefinition('${def.id}')" title="Edit">edit</i></td><td>${def.name}</td><td style="font-family:monospace;">${prefix || '-'}</td><td style="font-family:monospace;">${midfix || '-'}</td><td style="font-family:monospace;">${suffix || '-'}</td><td><i class="material-icons action-buttons danger" onclick="deleteDefinition('${def.id}')" title="Delete">delete_outline</i></td></tr>`);
            tbody.append(row);
        });
    }
    renderPagination(totalFilteredRecords);
}
function renderPagination(totalRecords) { 
    const paginationControls = $('#paginationControls'); paginationControls.empty();
    if (totalRecords <= recordsPerPage) return;
    const totalPages = Math.ceil(totalRecords / recordsPerPage); let paginationHTML = '';
    paginationHTML += `<button class="mui-btn mui-btn--small mui-btn--flat" onclick="changePage(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}>« Prev</button>`;
    const maxPagesToShow = 5; let startPage, endPage;
    if (totalPages <= maxPagesToShow) { startPage = 1; endPage = totalPages; }
    else { if (currentPage <= Math.ceil(maxPagesToShow / 2)) { startPage = 1; endPage = maxPagesToShow; } else if (currentPage + Math.floor(maxPagesToShow / 2) >= totalPages) { startPage = totalPages - maxPagesToShow + 1; endPage = totalPages; } else { startPage = currentPage - Math.floor(maxPagesToShow / 2); endPage = currentPage + Math.floor(maxPagesToShow / 2); } }
    if (startPage > 1) { paginationHTML += `<button class="mui-btn mui-btn--small mui-btn--flat" onclick="changePage(1)">1</button>`; if (startPage > 2) paginationHTML += `<span style="padding:0 5px;">...</span>`; }
    for (let i = startPage; i <= endPage; i++) { paginationHTML += `<button class="mui-btn mui-btn--small mui-btn--flat ${i === currentPage ? 'active' : ''}" onclick="changePage(${i})">${i}</button>`; }
    if (endPage < totalPages) { if (endPage < totalPages - 1) paginationHTML += `<span style="padding:0 5px;">...</span>`; paginationHTML += `<button class="mui-btn mui-btn--small mui-btn--flat" onclick="changePage(${totalPages})">${totalPages}</button>`; }
    paginationHTML += `<button class="mui-btn mui-btn--small mui-btn--flat" onclick="changePage(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''}>Next »</button>`;
    paginationControls.html(paginationHTML);
}
function changePage(page) { 
    const totalFilteredRecords = getFilteredDefinitions().length; const totalPages = Math.ceil(totalFilteredRecords / recordsPerPage);
    if (page < 1 && totalPages > 0) page = 1; // boundary checks
    if (page > totalPages) page = totalPages;

    if (currentPage === page) return; // No change if already on the target page
    currentPage = page; 
    renderDefinitionsTable();
}
function handleFilterInput(inputElement, type) { 
    filterAutocomplete(inputElement, type); 
    currentPage = 1; // Reset to first page on filter change
    renderDefinitionsTable();
}
function refreshDefinitions(){ 
    alert("Definitions refreshed."); currentPage = 1;
    try { const jsonDataString = $('#mockDefinitionsData').text(); definitions = JSON.parse(jsonDataString); } catch(e) { console.error("Error parsing mockDefinitionsData:", e); definitions = []; }
    $('#tenantFilterInput').val(''); $('#tenantFilterValue').val(''); $('#branchFilterInput').val(''); $('#branchFilterValue').val(''); $('#objectFilterInput').val(''); $('#objectFilterValue').val('');
    renderDefinitionsTable();
}
function filterAutocomplete(inputElement, type) { 
    const $input = $(inputElement); const filter = $input.val().toUpperCase();
    let dataList, $dropdown, $idField, valueKey = 'value', displayKey = 'name';
    switch(type) {
        case 'tenant': dataList = mockTenants; $dropdown = $('#tenantAutocompleteDropdown'); $idField = $('#tenantIdPrefixVal'); break;
        case 'country': dataList = mockCountries; $dropdown = $('#countryAutocompleteDropdown'); $idField = $('#countryCodeVal'); break;
        case 'branch': dataList = mockBranches; $dropdown = $('#branchAutocompleteDropdown'); $idField = $('#branchIdPrefixVal'); break;
        case 'object': dataList = mockObjects; $dropdown = $('#objectAutocompleteDropdown'); $idField = $('#objectIdentifierVal'); break;
        case 'tenantFilterList': dataList = mockTenants; $dropdown = $('#tenantFilterAutocompleteDropdown'); $idField = $('#tenantFilterValue'); break;
        case 'branchFilterList': dataList = mockBranches; $dropdown = $('#branchFilterAutocompleteDropdown'); $idField = $('#branchFilterValue'); break;
        case 'objectFilterList': dataList = mockObjects; $dropdown = $('#objectFilterAutocompleteDropdown'); $idField = $('#objectFilterValue'); break;
        case 'financialYear': dataList = mockFinancialYears; $dropdown = $('#financialYearAutocompleteDropdown'); $idField = $('#financialYearValue'); break;
        case 'timestampFormat': dataList = mockTimestampFormats; $dropdown = $('#timestampFormatAutocompleteDropdown'); $idField = $('#timestampFormatVal'); break;
        case 'uniquenessType': dataList = mockUniquenessTypes; $dropdown = $('#uniquenessTypeAutocompleteDropdown'); $idField = $('#uniquenessTypeVal'); break;
        case 'delimiter': dataList = mockDelimiters; $dropdown = $('#idDelimiterAutocompleteDropdown'); $idField = $('#idDelimiterVal'); break;
        default: return;
    }
    $dropdown.empty().hide();
    let showEvenIfEmptyAndFocused = ['objectFilterList', 'financialYear', 'timestampFormat', 'uniquenessType', 'delimiter', 'country', 'tenant', 'branch', 'object', 'tenantFilterList', 'branchFilterList'];
    if (filter.length === 0 && !($input.is(':focus') && showEvenIfEmptyAndFocused.includes(type)) ) { return; }
    const filteredData = (filter.length === 0 && $input.is(':focus') && showEvenIfEmptyAndFocused.includes(type)) ? dataList : dataList.filter(item => item[displayKey].toUpperCase().includes(filter));
    if (filteredData.length > 0) {
        filteredData.forEach(item => {
            const $div = $('<div>').text(item[displayKey]).on('click', function() {
                $input.val(item[displayKey]); $idField.val(item[valueKey]); $dropdown.empty().hide();
                if (type === 'object') { const selectedObject = mockObjects.find(o => o.value === item[valueKey]); $('#objectShortFormInput').val(selectedObject?.defaultShort || ''); }
                if (type.endsWith('FilterList')) { 
                    currentPage = 1; // Reset page on filter selection
                    renderDefinitionsTable(); 
                }
                if (type === 'uniquenessType') { handleUniquenessTypeChange(item[valueKey]); }
                generatePreview();
            });
            $dropdown.append($div);
        });
        $dropdown.show();
    } else if (filter.length > 0) { $dropdown.append('<div class="no-results">No results found</div>').show(); }
}
function handleUniquenessTypeChange(typeVal) { 
    $('#incrementConfig').toggle(typeVal === 'increment');
    $('#randomConfig').toggle(typeVal && (typeVal.startsWith('random') || typeVal.startsWith('uuid')));
}
$(document).on('click', function(event) { 
    if (!$(event.target).closest('.autocomplete-container').length && !$(event.target).is('.autocomplete-container > .mui-textfield > input')) { $('.autocomplete-dropdown').empty().hide(); }
});
$('.autocomplete-container > .mui-textfield > input').on('focus', function() { 
    const $inputField = $(this); let type = ''; const id = $inputField.attr('id');
    if (id === 'tenantNameInput') type = 'tenant'; else if (id === 'countryCodeInput') type = 'country'; else if (id === 'branchNameInput') type = 'branch'; else if (id === 'objectIdentifierInput') type = 'object'; else if (id === 'tenantFilterInput') type = 'tenantFilterList'; else if (id === 'branchFilterInput') type = 'branchFilterList'; else if (id === 'objectFilterInput') type = 'objectFilterList'; else if (id === 'financialYearInput') type = 'financialYear'; else if (id === 'timestampFormatInput') type = 'timestampFormat'; else if (id === 'uniquenessTypeInput') type = 'uniquenessType'; else if (id === 'idDelimiterInput') type = 'delimiter';
    if (type) { setTimeout(() => filterAutocomplete(this, type), 50); }
});
function generatePreview() { 
    const { full } = getExampleParts();
    $('#finalIdPreview').text(full || "Configure components...");
}
function getExampleParts(config = null) { 
    const parts = { prefixP: [], midfixP: [], uniquenessP: "", suffixP: [] }; const idDelimVal = config ? config.idDelimiterVal : $('#idDelimiterVal').val();
    const tenant = config ? config.tenantIdPrefixVal : $('#tenantIdPrefixVal').val(); if (tenant) parts.prefixP.push(tenant);
    const country = config ? config.countryCodeVal : $('#countryCodeVal').val(); if (country) parts.prefixP.push(country);
    const branch = config ? config.branchIdPrefixVal : $('#branchIdPrefixVal').val(); if (branch) parts.prefixP.push(branch);
    const objShort = config ? config.objectShortFormInput : $('#objectShortFormInput').val(); if (objShort) parts.prefixP.push(objShort);
    const includeTS = config ? config.includeTimestamp : $('#includeTimestamp').is(':checked');
    if (includeTS) { const tsFormat = config ? config.timestampFormatVal : $('#timestampFormatVal').val(); if (tsFormat === 'YYYYMMDDHHmmss') parts.midfixP.push('20240115103000'); else if (tsFormat === 'epoch_ms') parts.midfixP.push('1705314600000'); else if (tsFormat === 'YYMMDD') parts.midfixP.push('240115'); }
    const uType = config ? config.uniquenessTypeVal : $('#uniquenessTypeVal').val();
    if (uType === 'increment') { const startNum = config ? (config.uniqueStartNumber || 1) : (parseInt($('#uniqueStartNumber').val())||1); const padding = config ? (config.paddingLength || 5) : (parseInt($('#paddingLength').val())||5); parts.uniquenessP = startNum.toString().padStart(padding, '0'); }
    else if (uType && uType.startsWith('random')) { const len = config ? (config.randomLength || 8) : (parseInt($('#randomLength').val())||8); parts.uniquenessP = 'Abc123Xy'.substring(0, len); }
    else if (uType === 'uuid_short') { parts.uniquenessP = 'a1b2c3d4'; }
    const fyVal = config ? config.financialYearValue : $('#financialYearValue').val(); if (fyVal) { parts.suffixP.push(fyVal.slice(-4) || fyVal.slice(-2) || fyVal); }
    const allPartsForFull = []; if (parts.prefixP.length > 0) allPartsForFull.push(...parts.prefixP); if (parts.midfixP.length > 0) allPartsForFull.push(...parts.midfixP); if (parts.uniquenessP) allPartsForFull.push(parts.uniquenessP); if (parts.suffixP.length > 0) allPartsForFull.push(...parts.suffixP);
    let tableMidfix = parts.midfixP.length > 0 ? parts.midfixP.join(idDelimVal) : ""; if(parts.uniquenessP){ if(tableMidfix.length > 0 && idDelimVal) tableMidfix += idDelimVal; tableMidfix += parts.uniquenessP; }
    return { prefix: parts.prefixP.length > 0 ? parts.prefixP.join(idDelimVal) : "", midfix: tableMidfix, suffix: parts.suffixP.length > 0 ? parts.suffixP.join(idDelimVal) : "", full: allPartsForFull.length > 0 ? allPartsForFull.join(idDelimVal) : "Preview N/A" };
}

function toggleListPanel() {
    const listContainer = $('#definitionListContentContainer');
    const toggleBtn = $('#toggleListBtn');
    listContainer.toggleClass('collapsed');
    toggleBtn.text(listContainer.hasClass('collapsed') ? 'keyboard_arrow_down' : 'keyboard_arrow_up');
    
    if (!listContainer.hasClass('collapsed') && $('#definitionsTableBody').is(':empty') && getFilteredDefinitions().length === 0) {
        renderDefinitionsTable(); 
    }
}

$(document).ready(function() { 
    try { const jsonDataString = $('#mockDefinitionsData').text(); definitions = JSON.parse(jsonDataString); }
    catch(e) { console.error("Error parsing mockDefinitionsData:", e); definitions = []; }
    $('#definitionForm input, #definitionForm select').on('change input', generatePreview);
    $('#includeTimestamp').on('change', function() { $('#timestampFormatContainer').toggle($(this).is(':checked')); generatePreview(); });
    
    $('#toggleListBtn').text('keyboard_arrow_up'); 

    const tFormat = mockTimestampFormats[0]; if(tFormat){ $('#timestampFormatInput').val(tFormat.name); $('#timestampFormatVal').val(tFormat.value); }
    const uType = mockUniquenessTypes[0]; if(uType){ $('#uniquenessTypeInput').val(uType.name); $('#uniquenessTypeVal').val(uType.value); }
    handleUniquenessTypeChange($('#uniquenessTypeVal').val());
    const delim = mockDelimiters[0]; if(delim){ $('#idDelimiterInput').val(delim.name); $('#idDelimiterVal').val(delim.value); }
    const fy = mockFinancialYears[0]; if(fy){ $('#financialYearInput').val(fy.name); $('#financialYearValue').val(fy.value); }
    const country = mockCountries[0]; if(country){ $('#countryCodeInput').val(country.name); $('#countryCodeVal').val(country.value); }
    
    navigateTo('prefixSuffix', $('.app-sidenav ul li.active a')[0]);
});