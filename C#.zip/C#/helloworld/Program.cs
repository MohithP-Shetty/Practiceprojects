﻿using System;

class Program
{
    static void Main()
    {
        // See https://aka.ms/new-console-template for more information
        Console.WriteLine("Hello, World!");
        string firstString = "Welcome";
        string secondString = "to HClTech";
        Console.WriteLine($"{firstString} {secondString}");
    }
}




