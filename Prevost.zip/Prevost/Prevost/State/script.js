document.addEventListener('DOMContentLoaded', () => {
    // Initial Data
    const initialData = [ 
        { id: 1, name: 'Alabama', region: 'United States', active: true }, 
        { id: 2, name: 'Alaska', region: 'United States', active: true }, 
        { id: 3, name: 'Québec', region: 'Canada', active: true }, 
        { id: 4, name: 'Ontario', region: 'Canada', active: true }, 
        { id: 5, name: 'Jalisco', region: 'Mexico', active: true }, 
        { id: 6, name: 'Bavaria', region: 'Germany', active: true }, 
        { id: 7, name: 'Île-de-France', region: 'France', active: true }, 
        { id: 8, name: 'Maharashtra', region: 'India', active: true }, 
        { id: 9, name: 'Gauteng', region: 'South Africa', active: false }, 
        { id: 10, name: 'New South Wales', region: 'Australia', active: true }, 
        { id: 11, name: 'Stockholm', region: 'Sweden', active: true}, 
        { id: 12, name: 'Riyadh', region: 'Saudi Arabia', active: true}, 
        { id: 13, name: 'Mazovia', region: 'Poland', active: true}, 
        { id: 14, name: 'Flanders', region: 'Belgium', active: true},
    ];
    let statesData = JSON.parse(JSON.stringify(initialData)); // Deep copy to preserve initial state

    // Global Application State Variables
    const countries = ['All', 'United States', 'Canada', 'Mexico', 'India', 'Germany', 'France', 'Japan', 'Australia', 'South Africa', 'Sweden', 'Saudi Arabia', 'Poland', 'Belgium'];
    let activeCountry = 'All';
    let activeView = 'grid';
    let searchStateQuery = '';
    let searchCountryQuery = '';
    let editingStateId = null;
    let selectedStateIds = new Set();
    let statusChartInstance, regionChartInstance;
    let currentPage = 1;
    let itemsPerPage = 20;

    // Grid-specific state for column reordering and sorting
    let columnOrder = [
        { id: 'select', label: '', sortable: false, draggable: false }, // Checkbox column
        { id: 'name', label: 'State', sortable: true, field: 'name', draggable: true },
        { id: 'region', label: 'Region', sortable: true, field: 'region', draggable: true },
        { id: 'status', label: 'Status', sortable: true, field: 'active', draggable: true },
        { id: 'actions', label: 'Actions', sortable: false, draggable: false }
    ];
    let currentSortColumn = null;
    let sortDirection = 'asc'; // 'asc' or 'desc'

    // Helper function to get DOM elements by ID
    const getById = id => document.getElementById(id);

    // Cached DOM Elements
    const mainViews = { grid: getById('view-grid'), cards: getById('view-cards'), compact: getById('view-compact') };
    const viewButtons = { grid: getById('btn-grid'), cards: getById('btn-cards'), compact: getById('btn-compact') };
    const dataBodies = { 
        grid: getById('grid-data-body'), 
        cards: getById('cards-data-body'), 
        compactActive: getById('compact-active'), 
        compactInactive: getById('compact-inactive') 
    };
    const gridHeader = getById('grid-header'); // New: Reference to the grid table header

    const countrySelector = getById('country-selector'), 
          scrollLeftBtn = getById('scroll-left'), 
          scrollRightBtn = getById('scroll-right');
    const searchStateInput = getById('search-state-input'), 
          searchCountryInput = getById('search-country-input'), 
          addStateBtn = getById('add-state-btn'), 
          exportSelectedBtn = getById('export-selected-btn'), 
          deleteSelectedBtn = getById('delete-selected-btn'), 
          refreshBtn = getById('refresh-btn');
    const infoModal = getById('info-modal'), 
          infoModalTitle = getById('info-modal-title'), 
          infoModalBody = getById('info-modal-body'), 
          infoModalButtons = getById('info-modal-buttons');
    const bulkActionBar = getById('bulk-action-bar'), 
          selectAllGrid = getById('select-all-grid'), 
          selectAllNonGrid = getById('select-all-non-grid');
    const inlineAnalyticsContainer = getById('inline-analytics-container'), 
          analyticsBtn = getById('analytics-btn');
    const countryDropdown = getById('country-dropdown');
    const paginationFooter = getById('pagination-footer');
    const sideMenu = getById('side-menu'), 
          sideMenuOverlay = getById('side-menu-overlay'), 
          sideMenuContent = getById('side-menu-content'), 
          menuToggleBtn = getById('menu-toggle-btn'), 
          sideMenuCloseBtn = getById('side-menu-close-btn'), 
          controlPanelWrapper = getById('control-panel-wrapper');

    // --- Utility and Rendering Functions ---

    /**
     * Creates an HTML span element for status badge (Active/Inactive).
     * @param {boolean} isActive - True if the state is active, false otherwise.
     * @returns {string} HTML string for the status badge.
     */
    const createStatusBadge = (isActive) => `<span class="status-badge ${isActive ? 'status-badge-active' : 'status-badge-inactive'}">${isActive ? 'Active' : 'Inactive'}</span>`;

    /**
     * Creates an HTML label element containing a toggle switch.
     * @param {boolean} isActive - Initial checked state of the toggle.
     * @param {number|string} id - The ID of the state for data association.
     * @returns {string} HTML string for the toggle switch.
     */
    const createToggle = (isActive, id) => `<label class="flex items-center cursor-pointer"><span class="toggle-switch"><input type="checkbox" data-field="active" ${isActive ? 'checked' : ''} onchange="this.parentElement.nextElementSibling.textContent = this.checked ? 'Active' : 'Inactive'"><span class="toggle-slider"></span></span><span class="ml-3 text-sm font-medium text-gray-900 status-toggle-label" data-id="${id}">${isActive ? 'Active' : 'Inactive'}</span></label>`;

    /**
     * Creates HTML action buttons (Edit, Save, Cancel, Delete).
     * @param {number|string} id - The ID of the state.
     * @param {string} view - The current view ('grid', 'cards', 'compact').
     * @returns {string} HTML string for action buttons.
     */
    const createActionButtons = (id, view) => { 
        // If currently editing this state, show Save and Cancel buttons
        if (editingStateId === id) { 
            const buttonClass = view === 'compact' ? 'flex flex-col space-y-1' : 'flex items-center justify-end space-x-2'; 
            return `<div class="${buttonClass}">
                        <button class="save-btn font-semibold text-blue-600 text-sm">Save</button>
                        <button class="cancel-btn text-gray-600 text-sm">Cancel</button>
                    </div>`; 
        } 
        // Otherwise, show Edit and Delete buttons
        return `<div class="flex items-center justify-end space-x-1">
                    <button class="edit-btn p-2 text-gray-500 hover:text-black rounded-full" title="Edit">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                    </button>
                    <button class="delete-btn p-2 text-gray-500 hover:text-black rounded-full" title="Delete">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                    </button>
                </div>`; 
    };

    /**
     * Creates an editable input or select field for state properties.
     * @param {string} value - The current value of the field.
     * @param {string} field - The name of the field ('name', 'region', 'active').
     * @returns {string} HTML string for the editable field.
     */
    const createEditableField = (value, field) => { 
        if (field === 'region' && editingStateId && !String(editingStateId).startsWith('new')) { 
            return `<input type="text" class="w-full bg-gray-100 border-gray-200 rounded-md p-1 text-sm" value="${value}" data-field="${field}" disabled title="Region cannot be changed after creation.">`; 
        } 
        if (field === 'region' && activeCountry === 'All') { 
            const opts = countries.filter(c=>c!=='All').map(c=>`<option value="${c}" ${c===value?'selected':''}>${c}</option>`).join(''); 
            return `<select data-field="region" class="w-full bg-gray-100 border border-gray-300 rounded-md p-1 text-sm">${opts}</select>`; 
        } 
        return `<input type="text" class="w-full bg-gray-100 border-gray-300 rounded-md p-1 text-sm" value="${value}" data-field="${field}">`; 
    };
    
    /**
     * The main render function to update all data views based on current state.
     */
    const render = () => {
        // Filter and paginate data
        let allFilteredData = statesData.filter(s => 
            (activeCountry === 'All' || s.region === activeCountry) && 
            s.name.toLowerCase().includes(searchStateQuery.toLowerCase()) && 
            s.region.toLowerCase().includes(searchCountryQuery.toLowerCase())
        );

        // Apply sorting if a column is sorted
        if (currentSortColumn) {
            const sortField = columnOrder.find(col => col.id === currentSortColumn).field;
            allFilteredData.sort((a, b) => {
                const valA = String(a[sortField]).toLowerCase();
                const valB = String(b[sortField]).toLowerCase();
                if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
                if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
                return 0;
            });
        }
        
        const totalItems = allFilteredData.length;
        const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
        currentPage = Math.min(currentPage, totalPages); // Ensure current page doesn't exceed total pages
        const paginatedData = allFilteredData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

        // Render each view
        renderGridHeader(); // New: Render grid header dynamically
        dataBodies.grid.innerHTML = paginatedData.map(renderGridRow).join('');
        dataBodies.cards.innerHTML = paginatedData.map(renderCard).join('');
        dataBodies.compactActive.innerHTML = allFilteredData.filter(s => s.active).map(renderCompactDraggable).join('');
        dataBodies.compactInactive.innerHTML = allFilteredData.filter(s => !s.active).map(renderCompactDraggable).join('');
        
        // Update auxiliary controls
        updatePagination(totalItems, totalPages);
        updateBulkActionControls(allFilteredData);
        addStateBtn.disabled = !!editingStateId; // Disable add button if editing
    };
    
    /**
     * Renders a single row for the grid view.
     * @param {Object} state - The state object to render.
     * @returns {string} HTML string for a grid table row.
     */
    const renderGridRow = state => {
        let rowHtml = `<tr data-id="${state.id}" class="bg-white border-b hover:bg-gray-50">`;
        columnOrder.forEach(col => {
            if (col.id === 'select') {
                rowHtml += `<td class="p-2"><input type="checkbox" class="item-checkbox rounded border-gray-400" ${selectedStateIds.has(state.id)?'checked':''}></td>`;
            } else if (col.id === 'name') {
                rowHtml += `<td class="px-4 py-2">${editingStateId === state.id ? createEditableField(state.name, 'name') : `<span class="font-medium text-gray-900">${state.name}</span>`}</td>`;
            } else if (col.id === 'region') {
                rowHtml += `<td class="px-4 py-2">${editingStateId === state.id ? createEditableField(state.region, 'region') : state.region}</td>`;
            } else if (col.id === 'status') {
                rowHtml += `<td class="px-4 py-2">${editingStateId === state.id ? createToggle(state.active, state.id) : createStatusBadge(state.active)}</td>`;
            } else if (col.id === 'actions') {
                rowHtml += `<td class="px-4 py-2 text-right">${createActionButtons(state.id, 'grid')}</td>`;
            }
        });
        rowHtml += `</tr>`;
        return rowHtml;
    };

    /**
     * Renders a single card for the cards view.
     * @param {Object} state - The state object to render.
     * @returns {string} HTML string for a card.
     */
    const renderCard = state => `<div data-id="${state.id}" class="bg-white rounded-lg shadow-sm overflow-hidden"><div class="flex justify-between items-start p-3">${editingStateId === state.id ? `<div class="w-full space-y-2"><div>${createEditableField(state.name, 'name')}</div><div>${createEditableField(state.region, 'region')}</div><div>${createToggle(state.active, state.id)}</div></div>` : `<div class="flex-grow"><div class="flex items-start justify-between mb-2"><h3 class="text-base font-bold text-black">${state.name}</h3>${createStatusBadge(state.active)}</div><p class="text-sm text-gray-600"><span class="font-medium text-gray-900">Region:</span> ${state.region}</p></div>`}<input type="checkbox" class="item-checkbox rounded border-gray-400 ml-3 shrink-0" ${selectedStateIds.has(state.id)?'checked':''}></div><div class="bg-gray-50 px-3 py-2">${createActionButtons(state.id, 'cards')}</div></div>`;
    
    /**
     * Renders a single draggable item for the compact view.
     * @param {Object} state - The state object to render.
     * @returns {string} HTML string for a compact draggable item.
     */
    const renderCompactDraggable = state => `<div data-id="${state.id}" draggable="true" class="draggable-item bg-white p-2 rounded-lg shadow-sm flex items-center justify-between">${editingStateId === state.id ? `<div class="flex-grow mr-2 space-y-2"><div>${createEditableField(state.name, 'name')}</div><div>${createEditableField(state.region, 'region')}</div><div>${createToggle(state.active, state.id)}</div></div>` : `<div class="flex flex-col flex-grow"><p class="font-semibold truncate">${state.name}</p><p class="text-xs text-gray-500">${state.region}</p></div>`}<div class="flex items-center">${createActionButtons(state.id, 'compact')}</div></div>`;

    /**
     * Renders the grid table header dynamically, including drag handles and sort icons.
     */
    const renderGridHeader = () => {
        let headerHtml = '<tr>';
        columnOrder.forEach(col => {
            let sortIcon = '';
            if (col.sortable) {
                if (currentSortColumn === col.id) {
                    sortIcon = `<span class="sort-icon ${sortDirection}"></span>`;
                } else {
                    sortIcon = `<span class="sort-icon"></span>`; // Neutral icon
                }
            }

            let dragHandle = '';
            if (col.draggable) {
                dragHandle = `<svg class="drag-handle inline-block" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>`;
            }
            
            // Add data attributes for drag and sort functionality
            headerHtml += `<th scope="col" class="px-4 py-2 ${col.sortable ? 'sortable-header' : ''}" 
                                data-column-id="${col.id}" 
                                ${col.draggable ? 'draggable="true"' : ''}>
                                ${dragHandle}
                                <span class="label-text">${col.label}</span>
                                ${sortIcon}
                            </th>`;
        });
        headerHtml += '</tr>';
        gridHeader.innerHTML = headerHtml;
    };


    /**
     * Handles switching between different data views (Grid, Cards, Compact).
     * @param {string} viewId - The ID of the view to switch to.
     */
    function switchView(viewId) { 
        activeView = viewId; 
        Object.values(mainViews).forEach(v => v.classList.add('hidden')); 
        mainViews[viewId].classList.remove('hidden'); 
        Object.values(viewButtons).forEach(b => b.classList.remove('active')); 
        viewButtons[viewId].classList.add('active'); 
        
        // Adjust visibility of bulk action bar and pagination based on view
        bulkActionBar.classList.toggle('hidden', activeView === 'grid' || activeView === 'compact' || editingStateId !== null); 
        paginationFooter.classList.toggle('hidden', activeView === 'compact'); 
        
        render(); // Re-render the view
    }

    /**
     * Renders the country selector buttons and updates their active state.
     */
    const renderCountrySelector = () => { 
        countrySelector.innerHTML = countries.map(c => 
            `<button class="country-selector-item text-gray-500 py-2 px-2 shrink-0 ${c===activeCountry?'active':''}" data-country="${c}">${c}</button>`
        ).join(''); 
        updateScrollButtons(); 
    };

    /**
     * Handles actions triggered from within a state item (Edit, Save, Cancel, Delete).
     * @param {Event} e - The click event object.
     */
    const handleAction = e => { 
        const btn = e.target.closest('button'); 
        if (!btn) return; 
        const item = btn.closest('[data-id]'); 
        const id = item ? item.dataset.id : null; 
        const idNum = id && !id.startsWith('new') ? parseInt(id, 10) : id; // Convert to number if not a new ID

        if (btn.matches('.edit-btn')) { 
            editingStateId = idNum; 
            selectedStateIds.clear(); // Clear selections when editing
            render(); 
        } else if (btn.matches('.cancel-btn')) { 
            // If it's a new state, remove it from data
            if (String(id).startsWith('new-')) statesData.shift(); 
            editingStateId = null; 
            render(); 
        } else if (btn.matches('.save-btn')) { 
            handleSave(item); 
        } else if (btn.matches('.delete-btn')) { 
            handleDelete(idNum); 
        } 
    };

    /**
     * Handles saving an edited or new state item.
     * @param {HTMLElement} el - The HTML element containing the editable fields.
     */
    const handleSave = el => { 
        const id = el.dataset.id; 
        const idx = statesData.findIndex(s => s.id == id); // Use == for loose comparison (number vs string for new IDs)
        const nameInput = el.querySelector('[data-field="name"]');
        const regionInput = el.querySelector('[data-field="region"]');
        const activeInput = el.querySelector('[data-field="active"]');

        const name = nameInput.value.trim(); 
        const region = regionInput ? regionInput.value : statesData[idx].region; // If region is disabled, use existing value
        const active = activeInput.checked; 

        // Basic validation for state name
        if (!name || !/[a-zA-Z]/.test(name)) { 
            showAlert("Validation Error", "State name is required and must contain letters."); 
            return; 
        } 

        // Update the state data
        statesData[idx] = { ...statesData[idx], name, region, active }; 
        
        // Assign a new numeric ID if it was a 'new-' item
        if (String(id).startsWith('new-')) statesData[idx].id = Math.max(0, ...statesData.map(s=>typeof s.id==='number'?s.id:0)) + 1; 
        
        editingStateId = null; // Exit editing mode
        render(); 
    };

    /**
     * Handles deleting a single state item after confirmation.
     * @param {number|string} id - The ID of the state to delete.
     */
    const handleDelete = async id => { 
        const ok = await showConfirm('Confirm Deletion', 'This action cannot be undone.'); 
        if(ok){ 
            statesData = statesData.filter(s=>s.id !== id); 
            selectedStateIds.delete(id); 
            render(); 
        } 
    };

    /**
     * Handles deleting all selected state items after confirmation.
     */
    const handleDeleteSelected = async () => { 
        if(selectedStateIds.size === 0) return; 
        const ok = await showConfirm(`Delete ${selectedStateIds.size} items?`, 'This action cannot be undone.'); 
        if(ok){ 
            statesData = statesData.filter(s=>!selectedStateIds.has(s.id)); 
            selectedStateIds.clear(); 
            render(); 
        } 
    };

    /**
     * Displays a custom informational modal.
     * @param {string} title - The title of the modal.
     * @param {string} body - The message body of the modal.
     * @param {HTMLElement[]} buttons - Array of button HTML elements to display in the modal.
     */
    const showInfoModal = (title, body, buttons) => { 
        infoModalTitle.textContent=title; 
        infoModalBody.textContent=body; 
        infoModalButtons.innerHTML = ''; 
        buttons.forEach(btn => infoModalButtons.appendChild(btn)); 
        infoModal.classList.remove('hidden'); 
        setTimeout(()=>infoModal.classList.add('opacity-100'),10); 
    };

    /**
     * Hides the custom informational modal.
     */
    const hideInfoModal = () => { 
        infoModal.classList.remove('opacity-100'); 
        setTimeout(()=>infoModal.classList.add('hidden'), 200); 
    };

    /**
     * Displays a custom alert modal with an OK button.
     * @param {string} title - The title of the alert.
     * @param {string} body - The message body of the alert.
     */
    const showAlert = (title, body) => { 
        const okBtn = document.createElement('button'); 
        okBtn.className = 'px-4 py-2 bg-black text-white rounded-md hover:bg-gray-800'; 
        okBtn.textContent = 'OK'; 
        okBtn.onclick = hideInfoModal; 
        showInfoModal(title, body, [okBtn]); 
    };

    /**
     * Displays a custom confirmation modal with Confirm and Cancel buttons.
     * @param {string} title - The title of the confirmation.
     * @param {string} body - The message body of the confirmation.
     * @returns {Promise<boolean>} A promise that resolves to true if confirmed, false otherwise.
     */
    const showConfirm = (title, body) => { 
        return new Promise(resolve => { 
            const confirmBtn = document.createElement('button'); 
            confirmBtn.className = 'px-4 py-2 bg-black text-white rounded-md hover:bg-gray-800'; 
            confirmBtn.textContent = 'Confirm'; 
            confirmBtn.onclick = () => { hideInfoModal(); resolve(true); }; 
            
            const cancelBtn = document.createElement('button'); 
            cancelBtn.className = 'px-4 py-2 bg-gray-200 text-black rounded-md hover:bg-gray-300'; 
            cancelBtn.textContent = 'Cancel'; 
            cancelBtn.onclick = () => { hideInfoModal(); resolve(false); }; 
            
            showInfoModal(title, body, [cancelBtn, confirmBtn]); 
        }); 
    };

    /**
     * Updates the disabled state of the country selector scroll buttons.
     */
    const updateScrollButtons = () => { 
        const {scrollLeft,scrollWidth,clientWidth}=countrySelector; 
        scrollLeftBtn.disabled=scrollLeft<=0; 
        scrollRightBtn.disabled=scrollLeft>=scrollWidth-clientWidth-1; 
    };

    /**
     * Scrolls the country selector horizontally.
     * @param {number} dir - Direction of scroll (-1 for left, 1 for right).
     */
    const scrollCountries = dir => countrySelector.scrollBy({left:dir * countrySelector.parentElement.clientWidth, behavior:'smooth'});

    /**
     * Handles individual item checkbox selection.
     * @param {Event} e - The change event object.
     */
    const handleSelection = e => { 
        if(!e.target.matches('.item-checkbox')) return; 
        const id = parseInt(e.target.closest('[data-id]').dataset.id,10); 
        if(e.target.checked) selectedStateIds.add(id); 
        else selectedStateIds.delete(id); 
        render(); 
    };

    /**
     * Handles the "Select All" checkbox in bulk action bar.
     * @param {Event} e - The change event object.
     */
    const handleSelectAll = e => { 
        const fData = statesData.filter(s=>(activeCountry==='All'||s.region===activeCountry)); 
        const isChecked = e.target.checked; 
        selectedStateIds.clear(); 
        if(isChecked) fData.forEach(s=>selectedStateIds.add(s.id)); 
        render(); 
    };

    /**
     * Updates the enabled/disabled state of bulk action buttons and "Select All" checkboxes.
     * @param {Object[]} fData - The currently filtered data.
     */
    const updateBulkActionControls = fData => { 
        const hasSel = selectedStateIds.size>0; 
        deleteSelectedBtn.disabled=!hasSel; 
        exportSelectedBtn.disabled=!hasSel; 
        const allVisSel = fData.length>0 && fData.every(s=>selectedStateIds.has(s.id)); 
        selectAllGrid.checked=allVisSel; 
        selectAllNonGrid.checked=allVisSel; 
    };

    /**
     * Updates and renders the analytics charts (Status Distribution, States per Region).
     */
    const updateAnalyticsCharts = () => { 
        if (inlineAnalyticsContainer.classList.contains('hidden')) return; 

        const data = (activeCountry === 'All' ? statesData : statesData.filter(s => s.region === activeCountry)); 
        getById('analytics-title').textContent = `Analytics: ${activeCountry}`; 
        
        const activeCount = data.filter(s => s.active).length; 
        const inactiveCount = data.length - activeCount; 
        
        getById('stats-total').textContent = data.length; 
        getById('stats-active').textContent = activeCount; 
        getById('stats-inactive').textContent = inactiveCount; 
        
        // Status Chart (Doughnut)
        if (statusChartInstance) statusChartInstance.destroy(); 
        statusChartInstance = new Chart(getById('status-chart'), { 
            type: 'doughnut', 
            data: { 
                labels: ['Active', 'Inactive'], 
                datasets: [{ 
                    data: [activeCount, inactiveCount], 
                    backgroundColor: ['#111827', '#FFFFFF'], 
                    borderColor: '#FFFFFF', 
                    borderWidth: 2 
                }] 
            }, 
            options: { 
                responsive: true, 
                maintainAspectRatio: false, 
                plugins: { 
                    legend: { 
                        position: 'bottom' 
                    }
                }
            }
        }); 

        // Region Chart (Bar)
        const regionData = {}; 
        (activeCountry === 'All' ? statesData : data).forEach(s => { 
            regionData[s.region] = (regionData[s.region] || 0) + 1 
        }); 
        if (regionChartInstance) regionChartInstance.destroy(); 
        regionChartInstance = new Chart(getById('region-chart'), { 
            type: 'bar', 
            data: { 
                labels: Object.keys(regionData), 
                datasets: [{ 
                    label: '# of States', 
                    data: Object.values(regionData), 
                    backgroundColor: '#6B7280', 
                    borderColor: '#4B5563', 
                    borderWidth: 1 
                }] 
            }, 
            options: { 
                responsive: true, 
                maintainAspectRatio: false, 
                plugins: { 
                    legend: { 
                        display: false 
                    }
                }, 
                scales: { 
                    y: { 
                        beginAtZero: true, 
                        ticks: { 
                            stepSize: 1 
                        }
                    }
                }
            }
        }); 
    };

    /**
     * Toggles the visibility of the inline analytics container.
     */
    const toggleAnalytics = () => { 
        inlineAnalyticsContainer.classList.toggle('hidden'); 
        analyticsBtn.classList.toggle('active'); 
        updateAnalyticsCharts(); 
    };

    /**
     * Sets the active country filter and re-renders the data.
     * @param {string} country - The country/region to filter by.
     */
    const setActiveCountry = (country) => { 
        currentPage = 1; 
        activeCountry = country; 
        searchCountryQuery = country === 'All' ? '' : country; 
        searchCountryInput.value = searchCountryQuery; 
        renderCountrySelector(); 
        render(); 
        updateAnalyticsCharts(); 
    };

    /**
     * Updates the pagination display and controls.
     * @param {number} totalItems - Total number of filtered items.
     * @param {number} totalPages - Total number of pages.
     */
    const updatePagination = (totalItems, totalPages) => { 
        getById('page-current').value = currentPage; 
        getById('page-total').textContent = totalPages; 
        getById('page-first').disabled = currentPage === 1; 
        getById('page-prev').disabled = currentPage === 1; 
        getById('page-next').disabled = currentPage === totalPages; 
        getById('page-last').disabled = currentPage === totalPages; 
        
        const startItem = totalItems === 0 ? 0 : (currentPage - 1) * itemsPerPage + 1; 
        const endItem = Math.min(currentPage * itemsPerPage, totalItems); 
        getById('record-count').textContent = `View ${startItem}-${endItem} of ${totalItems}`;
    };

    // --- Grid Column Reordering (Drag and Drop) ---
    let draggedColumn = null; // Stores the TH element being dragged
    let dragOverColumn = null; // Stores the TH element being dragged over

    /**
     * Handles the start of a drag operation on a table header.
     * @param {Event} e - The dragstart event.
     */
    const handleColumnDragStart = e => {
        const targetTh = e.target.closest('th[draggable="true"]');
        if (!targetTh) return;

        draggedColumn = targetTh;
        e.dataTransfer.effectAllowed = 'move';
        // Set a dummy data for Firefox compatibility, actual data is managed internally
        e.dataTransfer.setData('text/plain', targetTh.dataset.columnId); 
        setTimeout(() => targetTh.classList.add('dragging'), 0); // Add class after drag starts
    };

    /**
     * Handles a drag over event on a table header.
     * @param {Event} e - The dragover event.
     */
    const handleColumnDragOver = e => {
        e.preventDefault(); // Necessary to allow drop
        const targetTh = e.target.closest('th[draggable="true"]');
        if (targetTh && draggedColumn && targetTh !== draggedColumn) {
            if (dragOverColumn) dragOverColumn.classList.remove('drag-over');
            dragOverColumn = targetTh;
            dragOverColumn.classList.add('drag-over');
            e.dataTransfer.dropEffect = 'move';
        }
    };

    /**
     * Handles a drag leave event on a table header.
     * @param {Event} e - The dragleave event.
     */
    const handleColumnDragLeave = e => {
        const targetTh = e.target.closest('th[draggable="true"]');
        if (targetTh && dragOverColumn === targetTh) {
            dragOverColumn.classList.remove('drag-over');
            dragOverColumn = null;
        }
    };

    /**
     * Handles a drop event on a table header, reordering columns.
     * @param {Event} e - The drop event.
     */
    const handleColumnDrop = e => {
        e.preventDefault();
        if (draggedColumn && dragOverColumn && draggedColumn !== dragOverColumn) {
            const draggedId = draggedColumn.dataset.columnId;
            const dropTargetId = dragOverColumn.dataset.columnId;

            const draggedColIndex = columnOrder.findIndex(col => col.id === draggedId);
            const dropTargetColIndex = columnOrder.findIndex(col => col.id === dropTargetId);

            if (draggedColIndex !== -1 && dropTargetColIndex !== -1) {
                const [removed] = columnOrder.splice(draggedColIndex, 1);
                columnOrder.splice(dropTargetColIndex, 0, removed);
                render(); // Re-render the table with new column order
            }
        }
        // Clean up drag visual feedback
        if (draggedColumn) draggedColumn.classList.remove('dragging');
        if (dragOverColumn) dragOverColumn.classList.remove('drag-over');
        draggedColumn = null;
        dragOverColumn = null;
    };

    /**
     * Handles the end of a drag operation.
     * @param {Event} e - The dragend event.
     */
    const handleColumnDragEnd = () => {
        if (draggedColumn) draggedColumn.classList.remove('dragging');
        if (dragOverColumn) dragOverColumn.classList.remove('drag-over');
        draggedColumn = null;
        dragOverColumn = null;
    };

    // --- Grid Column Sorting ---
    /**
     * Handles a click on a sortable column header to trigger sorting.
     * @param {Event} e - The click event.
     */
    const handleColumnSort = e => {
        const targetTh = e.target.closest('th.sortable-header');
        if (!targetTh) return;

        const columnId = targetTh.dataset.columnId;

        if (currentSortColumn === columnId) {
            sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            currentSortColumn = columnId;
            sortDirection = 'asc';
        }
        render(); // Re-render with sorted data
    };

    // --- Event Listeners ---

    // Add new state button handler
    addStateBtn.onclick = () => { 
        if (editingStateId) return; // Prevent adding if already editing
        editingStateId = null; 
        selectedStateIds.clear(); 
        statesData.unshift({ id: `new-${Date.now()}`, name: '', region: activeCountry === 'All' ? 'United States' : activeCountry, active: true }); 
        editingStateId = statesData[0].id; // Set new state to be immediately editable
        render(); 
    };

    // Refresh data button handler
    refreshBtn.onclick = () => { 
        statesData = JSON.parse(JSON.stringify(initialData)); // Reset to initial data
        selectedStateIds.clear(); 
        editingStateId = null; 
        setActiveCountry('All'); 
        searchStateInput.value = ''; 
        searchStateQuery = ''; 
        currentSortColumn = null; // Reset sort
        sortDirection = 'asc'; // Reset sort direction
        render(); 
    };

    // Delete selected items button handler
    deleteSelectedBtn.onclick = handleDeleteSelected;

    // Export selected items button handler
    exportSelectedBtn.onclick = () => { 
        if (selectedStateIds.size > 0) {
            const selectedItems = Array.from(selectedStateIds).map(id => statesData.find(s=>s.id===id));
            console.log('Exporting:', JSON.stringify(selectedItems, null, 2));
            showAlert('Export Successful', `Exported ${selectedItems.length} selected items to console.`);
        } else {
            showAlert('Export Failed', 'Please select at least one item to export.'); 
        }
    };

    // State search input handler
    searchStateInput.oninput = e => { searchStateQuery = e.target.value; render(); };

    // Country selector click handler
    countrySelector.onclick = e => { 
        if (e.target.matches('.country-selector-item')) setActiveCountry(e.target.dataset.country); 
    };

    // Attach event listeners to view buttons
    Object.keys(viewButtons).forEach(id => viewButtons[id].onclick = () => switchView(id));

    // Event delegation for action buttons (edit, save, cancel, delete) within data views
    getById('data-views').addEventListener('click', handleAction);
    // Event delegation for item checkboxes within data views
    getById('data-views').addEventListener('change', e => { handleSelection(e); });

    // Select All checkboxes handlers
    selectAllGrid.onchange = handleSelectAll; 
    selectAllNonGrid.onchange = handleSelectAll;

    // Country selector scroll buttons handlers
    scrollLeftBtn.onclick = () => scrollCountries(-1); 
    scrollRightBtn.onclick = () => scrollCountries(1);
    // Update scroll buttons on country selector scroll
    countrySelector.addEventListener('scroll', updateScrollButtons);

    // Close info modal when clicking outside
    infoModal.addEventListener('click', e => { if(e.target === infoModal) hideInfoModal(); });

    // Analytics button handler
    analyticsBtn.onclick = toggleAnalytics;

    // Pagination controls handlers
    getById('page-first').onclick = () => { currentPage = 1; render(); };
    getById('page-prev').onclick = () => { if (currentPage > 1) { currentPage--; render(); } };
    getById('page-next').onclick = () => { 
        const totalPages = Math.ceil(statesData.filter(s => (activeCountry === 'All' || s.region === activeCountry)).length / itemsPerPage); 
        if (currentPage < totalPages) { currentPage++; render(); }
    };
    getById('page-last').onclick = () => { 
        currentPage = Math.ceil(statesData.filter(s => (activeCountry === 'All' || s.region === activeCountry)).length / itemsPerPage); 
        render(); 
    };
    getById('page-current').onchange = (e) => { 
        const page = parseInt(e.target.value, 10); 
        const totalPages = Math.ceil(statesData.filter(s => (activeCountry === 'All' || s.region === activeCountry)).length / itemsPerPage); 
        if (page >= 1 && page <= totalPages) { 
            currentPage = page; 
        } 
        render(); 
    };
    getById('items-per-page').onchange = (e) => { 
        itemsPerPage = parseInt(e.target.value, 10); 
        currentPage = 1; // Reset to first page when items per page changes
        render(); 
    };

    // Compact view drag and drop (status change) handlers
    let dragId=null; 
    document.addEventListener('dragstart', e=>{
        if(e.target.matches('.draggable-item')){
            dragId=e.target.dataset.id;
            // For compact view drag, add a class to the original element
            e.target.classList.add('dragging');
        }
    });
    document.querySelectorAll('.drop-zone').forEach(z=>{
        z.addEventListener('dragover',e=>{e.preventDefault();z.classList.add('drag-over')});
        z.addEventListener('dragleave',e=>z.classList.remove('drag-over'));
        z.addEventListener('drop',e=>{
            e.preventDefault();
            z.classList.remove('drag-over');
            if(dragId){
                const s=statesData.find(st=>st.id==dragId);
                if(s){
                    s.active=z.id==='compact-active';
                    render();
                }
            }
        });
    });
    // Remove dragging class when drag ends (for compact view)
    document.addEventListener('dragend', e => {
        if (e.target.matches('.draggable-item')) {
            e.target.classList.remove('dragging');
            dragId = null;
        }
    });

    // Touch event handlers for compact view drag and drop
    let touchGhost=null, draggedEl=null;
    const handleTouchStart = e => { 
        if (!e.target.matches('.draggable-item')) return; 
        draggedEl = e.target; 
        const rect = draggedEl.getBoundingClientRect(); 
        touchGhost = draggedEl.cloneNode(true); 
        touchGhost.classList.add('touch-ghost'); 
        document.body.appendChild(touchGhost); 
        touchGhost.style.width=`${rect.width}px`; 
        touchGhost.style.top=`${e.touches[0].clientY}px`; 
        touchGhost.style.left=`${e.touches[0].clientX}px`; 
        draggedEl.classList.add('dragging'); 
    };
    const handleTouchMove = e => { 
        if(!touchGhost) return; 
        e.preventDefault(); // Prevent default touch scrolling
        touchGhost.style.top=`${e.touches[0].clientY}px`; 
        touchGhost.style.left=`${e.touches[0].clientX}px`; 
        
        const elUnder = document.elementFromPoint(e.touches[0].clientX, e.touches[0].clientY); 
        const dropZone = elUnder ? elUnder.closest('.drop-zone') : null; 
        
        document.querySelectorAll('.drop-zone').forEach(z => z.classList.remove('drag-over')); 
        if(dropZone) dropZone.classList.add('drag-over'); 
    };
    const handleTouchEnd = e => { 
        if(!touchGhost) return; 
        const elUnder = document.elementFromPoint(e.changedTouches[0].clientX, e.changedTouches[0].clientY); 
        const dropZone = elUnder ? elUnder.closest('.drop-zone') : null; 
        
        if(dropZone) { 
            const state = statesData.find(s=>s.id == draggedEl.dataset.id); 
            if(s){ 
                s.active = dropZone.id === 'compact-active'; 
                render(); 
            } 
        } 
        document.querySelectorAll('.drop-zone').forEach(z => z.classList.remove('drag-over')); 
        draggedEl.classList.remove('dragging'); 
        document.body.removeChild(touchGhost); 
        touchGhost=null; 
        draggedEl=null; 
    };
    document.addEventListener('touchstart', handleTouchStart); 
    document.addEventListener('touchmove', handleTouchMove, {passive:false}); 
    document.addEventListener('touchend', handleTouchEnd);

    // Side menu toggle handlers
    menuToggleBtn.onclick = openSideMenu;
    sideMenuCloseBtn.onclick = closeSideMenu;
    sideMenuOverlay.onclick = closeSideMenu;

    // --- Grid Header Event Listeners (Column D&D and Sort) ---
    // Using event delegation on the gridHeader itself
    gridHeader.addEventListener('dragstart', handleColumnDragStart);
    gridHeader.addEventListener('dragover', handleColumnDragOver);
    gridHeader.addEventListener('dragleave', handleColumnDragLeave);
    gridHeader.addEventListener('drop', handleColumnDrop);
    gridHeader.addEventListener('dragend', handleColumnDragEnd);
    gridHeader.addEventListener('click', handleColumnSort); // For sorting

    // Initial render calls
    switchView('grid'); // Set initial view to grid
    renderCountrySelector(); // Render initial country filter buttons
});