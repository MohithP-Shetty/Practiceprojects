// Dashboard functionality
document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
    initializeHeaderControls();
    initializeBookmarking(); // Initialize bookmarking features
    initializeSidebars(); // Initialize the sidebars
    initializeLayoutToggle(); // Initialize the new layout toggle feature
});

// Initialize dashboard functionality
function initializeDashboard() {
    console.log('Starting dashboard initialization...');
    loadUserInfo();
    initializeNavigation();
    initializeHeaderComponents();
    initializeSearchBar();
    // initializeLogout is called within initializeHeaderControls now
    console.log('Dashboard initialization complete');
}

// Initialize navigation functionality
function initializeNavigation() {
    initializeBreadcrumbNavigation();
    setInitialNavigationState();
}

// Initialize breadcrumb navigation
function initializeBreadcrumbNavigation() {
    const breadcrumbItems = document.querySelectorAll('.breadcrumb span:not(.material-icons)');
    breadcrumbItems.forEach((item, index) => {
        if (index === 0) { // Home breadcrumb
            item.style.cursor = 'pointer';
            item.addEventListener('click', () => navigateToSection('dashboard'));
        }
    });
}

// Set initial navigation state
function setInitialNavigationState() {
    const hash = window.location.hash.substring(1);
    const section = hash || 'dashboard';
    updateDashboardSection(section);
}

// Navigate to a specific section
function navigateToSection(section) {
    window.location.hash = section;
    updateDashboardSection(section);
}

// Load user information
function loadUserInfo() {
    const urlParams = new URLSearchParams(window.location.search);
    const userName = urlParams.get('user') || localStorage.getItem('dashboard_user_name') || 'Administrator';
    const userRole = urlParams.get('role') || localStorage.getItem('dashboard_user_role') || 'Admin';

    const userNameElement = document.getElementById('userName');
    if (userNameElement) {
        userNameElement.textContent = userName;
    }
    localStorage.setItem('dashboard_user_name', userName);
    localStorage.setItem('dashboard_user_role', userRole);
}

// Initialize header components
function initializeHeaderComponents() {
    initializeSearchBar();
}

// Enhanced search bar functionality
function initializeSearchBar() {
    const searchInput = document.getElementById('search-input');
    const searchResults = document.getElementById('search-results');
    const searchOverlay = document.getElementById('search-overlay');
    const searchResultsClose = document.getElementById('search-results-close');
    const clearRecentBtn = document.getElementById('clear-recent-searches');
    const clearSearchBtn = document.getElementById('search-clear-btn');

    if (!searchInput || !searchResults) return;

    let searchTimeout;
    let selectedIndex = -1;
    let recentSearches = JSON.parse(localStorage.getItem('recentSearches') || '[]');
    let searchData = [];

    function hideSearchResults() {
        searchResults.classList.remove('active');
        if (searchOverlay) searchOverlay.classList.remove('active');
        if (clearSearchBtn) clearSearchBtn.style.display = 'none';
    }

    function dismissSearch() {
        hideSearchResults();
        searchInput.value = '';
        showRecentSearches();
    }

    searchInput.addEventListener('input', function() {
        const query = this.value.trim();
        if (clearSearchBtn) {
            clearSearchBtn.style.display = query.length > 0 ? 'block' : 'none';
        }

        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            if (query.length > 0) {
                searchData = buildSearchData();
                performEnhancedSearch(query, searchData);
                showSearchResults();
            } else {
                hideSearchResults();
            }
        }, 200);
    });
    
    if (clearSearchBtn) {
        clearSearchBtn.addEventListener('click', () => {
            searchInput.value = '';
            clearSearchBtn.style.display = 'none';
            hideSearchResults();
            searchInput.focus();
        });
    }

    searchInput.addEventListener('keydown', function(e) {
        const items = searchResults.querySelectorAll('.search-item');
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            selectedIndex = Math.min(selectedIndex + 1, items.length - 1);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            selectedIndex = Math.max(selectedIndex - 1, -1);
        } else if (e.key === 'Enter' && selectedIndex >= 0) {
            e.preventDefault();
            items[selectedIndex]?.click();
        } else if (e.key === 'Escape') {
            e.preventDefault();
            dismissSearch();
        }
        updateSearchSelection(items);
    });

    if (searchOverlay) searchOverlay.addEventListener('click', dismissSearch);
    if (searchResultsClose) searchResultsClose.addEventListener('click', dismissSearch);

    if (clearRecentBtn) {
        clearRecentBtn.addEventListener('click', () => {
            recentSearches = [];
            localStorage.setItem('recentSearches', JSON.stringify(recentSearches));
            showRecentSearches();
        });
    }

    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            searchInput.focus();
        }
    });

    function showSearchResults() {
        searchResults.classList.add('active');
        if (searchOverlay) searchOverlay.classList.add('active');
        selectedIndex = -1;
    }

    function updateSearchSelection(items) {
        items.forEach((item, index) => {
            item.classList.toggle('selected', index === selectedIndex);
        });
        const selectedItem = searchResults.querySelector('.search-item.selected');
        if (selectedItem) selectedItem.scrollIntoView({ block: 'nearest' });
    }

    function highlightText(text, query) {
        if (!query || !text) return text || '';
        const safeQuery = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        return text.replace(new RegExp(`(${safeQuery})`, 'gi'), '<mark>$1</mark>');
    }

    function createSearchResultElement(item, query) {
        const el = document.createElement('button');
        el.className = 'search-item';
        
        const breadcrumbsHTML = highlightText(item.breadcrumbs, query).replace(/&gt;/g, '<span class="breadcrumb-separator">></span>');

        el.innerHTML = `
            <div class="search-item-icon">
                 <i class="${item.icon}"></i>
            </div>
            <div class="search-item-content">
                <div class="search-item-title">${highlightText(item.name, query)}</div>
                <div class="search-item-breadcrumbs">${breadcrumbsHTML}</div>
            </div>`;
        
        el.addEventListener('click', () => {
            console.log(`Navigating to: ${item.name} at ${item.href}`);
            if (item.href && item.href !== '#') {
                window.location.href = item.href;
            }
            dismissSearch(); 
        });
        return el;
    }

    function displaySearchResults(results, query) {
        const searchItemsContainer = document.getElementById('search-items');
        const resultsCountEl = document.querySelector('.results-count');
        const searchTermEl = document.querySelector('.search-term');
        const noResultsEl = document.getElementById('search-no-results');
        const searchSection = document.getElementById('search-results-section');
        const recentSection = document.getElementById('recent-searches-section');

        if (!searchItemsContainer) return;

        if (resultsCountEl) resultsCountEl.textContent = `${results.length} result${results.length !== 1 ? 's' : ''}`;
        if (searchTermEl) searchTermEl.textContent = query ? `for "${query}"` : '';

        if (query) {
            if (recentSection) recentSection.style.display = 'none';
            if (searchSection) searchSection.style.display = 'block';
        } else {
            if (recentSection) recentSection.style.display = 'block';
            if (searchSection) searchSection.style.display = 'none';
        }

        searchItemsContainer.innerHTML = '';
        if (noResultsEl) noResultsEl.style.display = results.length === 0 && query ? 'block' : 'none';

        results.forEach(item => {
            searchItemsContainer.appendChild(createSearchResultElement(item, query));
        });
    }

    function showRecentSearches() {
        const recentContainer = document.getElementById('recent-searches');
        const recentSection = document.getElementById('recent-searches-section');
        const searchSection = document.getElementById('search-results-section');

        if (!recentContainer) return;

        if (recentSection) recentSection.style.display = recentSearches.length > 0 ? 'block' : 'none';
        if (searchSection) searchSection.style.display = 'none';

        recentContainer.innerHTML = '';
        recentSearches.forEach(search => {
            const el = document.createElement('button');
            el.className = 'search-item';
            el.innerHTML = `
                <div class="search-item-icon"><i class="fas fa-history"></i></div>
                <div class="search-item-content">
                    <div class="search-item-title">${search}</div>
                    <div class="search-item-description">Recent search</div>
                </div>`;
            el.addEventListener('click', () => {
                searchInput.value = search;
                searchData = buildSearchData();
                performEnhancedSearch(search, searchData);
                showSearchResults();
            });
            recentContainer.appendChild(el);
        });
    }

    function performEnhancedSearch(query, data) {
        const searchTerm = query.toLowerCase();
        const results = data
            .map(item => {
                let score = 0;
                if (item.name.toLowerCase().startsWith(searchTerm)) score += 10;
                else if (item.name.toLowerCase().includes(searchTerm)) score += 5;
                if (item.description.toLowerCase().includes(searchTerm)) score += 3;
                if (item.category.toLowerCase().includes(searchTerm)) score += 2;
                return { ...item, score };
            })
            .filter(item => item.score > 0)
            .sort((a, b) => b.score - a.score);

        displaySearchResults(results.slice(0, 15), query);
    }
    
    showRecentSearches();
}

// Build comprehensive search data
function buildSearchData() {
    const items = [];
    document.querySelectorAll('.mega-card').forEach(card => {
        const parentMenu = card.closest('.dropdown-menu');
        const menuName = parentMenu?.id.replace('-menu', '').replace(/^\w/, c => c.toUpperCase()) || 'General';
        
        const activeTab = parentMenu?.querySelector('.mega-menu-tab.active');
        const tabName = activeTab?.textContent.trim();

        const breadcrumbs = [menuName];
        if (tabName) breadcrumbs.push(tabName);
        breadcrumbs.push(card.querySelector('h4')?.textContent.trim() || 'Untitled');

        items.push({
            name: card.querySelector('h4')?.textContent.trim() || 'Untitled',
            description: card.querySelector('p')?.textContent.trim() || 'No description',
            category: menuName,
            breadcrumbs: breadcrumbs.join(' > '),
            icon: card.querySelector('.mega-card-icon i')?.className || 'fas fa-question-circle',
            href: card.getAttribute('href') || '#'
        });
    });
    return items;
}

// Initialize header controls
function initializeHeaderControls() {
    initializeBranchSelector();
    initializeLanguageSelector();
    initializeLogoutButton();

    document.addEventListener('click', (e) => {
        if (!e.target.closest('.header-dropdown')) closeAllDropdowns();
    });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeAllDropdowns();
    });
}

function initializeBranchSelector() {
    const btn = document.getElementById('branch-selector-btn');
    const dropdown = document.getElementById('branch-dropdown');
    const container = btn?.closest('.branch-selector');
    if (!btn || !dropdown || !container) return;

    btn.addEventListener('click', e => {
        e.stopPropagation();
        toggleDropdown(container, dropdown);
    });

    const setActiveBranch = (branchValue) => {
        const item = dropdown.querySelector(`[data-branch="${branchValue}"]`);
        if (item) {
            const name = item.querySelector('span').textContent;
            const btnText = btn.querySelector('.header-control-text');
            if (btnText) btnText.textContent = name;
            
            dropdown.querySelectorAll('.dropdown-item').forEach(i => i.classList.remove('active'));
            item.classList.add('active');
        }
    };

    dropdown.addEventListener('click', e => {
        const item = e.target.closest('.dropdown-item');
        if (item) {
            const value = item.dataset.branch;
            localStorage.setItem('selectedBranch', value);
            setActiveBranch(value);
            closeDropdown(container, dropdown);
        }
    });

    const savedBranch = localStorage.getItem('selectedBranch') || 'main';
    setActiveBranch(savedBranch);
}

function initializeLanguageSelector() {
    const toggleBtn = document.getElementById('language-toggle-btn');
    if (!toggleBtn) return;

    const btnText = toggleBtn.querySelector('.header-control-text');
    let currentLang = localStorage.getItem('selectedLanguage') || 'en';

    const setLanguage = (lang) => {
        currentLang = lang;
        if (btnText) btnText.textContent = lang.toUpperCase();
        localStorage.setItem('selectedLanguage', lang);
        console.log(`Language switched to: ${lang}`);
    };
    
    setLanguage(currentLang);

    toggleBtn.addEventListener('click', () => {
        const newLang = currentLang === 'en' ? 'fr' : 'en';
        setLanguage(newLang);
    });
}

function initializeLogoutButton() {
    const logoutBtn = document.getElementById('logout-btn');
    const logoutModal = document.getElementById('logoutConfirmModal');
    const confirmLogoutBtn = document.getElementById('confirmLogoutBtn');
    const cancelLogoutBtn = document.getElementById('cancelLogoutBtn');
    const closeLogoutModalBtn = document.getElementById('closeLogoutConfirm');

    if (!logoutBtn || !logoutModal || !confirmLogoutBtn || !cancelLogoutBtn || !closeLogoutModalBtn) {
        console.error("Logout modal elements could not be found. Please check HTML IDs.");
        return;
    }

    const showModal = () => logoutModal?.classList.add('show');
    const hideModal = () => logoutModal?.classList.remove('show');

    logoutBtn.addEventListener('click', showModal);
    cancelLogoutBtn.addEventListener('click', hideModal);
    closeLogoutModalBtn.addEventListener('click', hideModal);
    logoutModal.addEventListener('click', (e) => {
        if (e.target === logoutModal) hideModal();
    });

    confirmLogoutBtn.addEventListener('click', () => {
        localStorage.clear();
        const liveRegion = document.getElementById('live-region');
        if (liveRegion) liveRegion.textContent = 'Logout successful. Redirecting...';
        hideModal();
        setTimeout(() => { window.location.href = 'index.html'; }, 500);
    });
}

function toggleDropdown(container, dropdown) {
    const isActive = container.classList.contains('active');
    closeAllDropdowns();
    if (!isActive) {
        container.classList.add('active');
        dropdown.classList.add('show');
    }
}

function closeDropdown(container, dropdown) {
    container.classList.remove('active');
    dropdown.classList.remove('show');
}

function closeAllDropdowns() {
    document.querySelectorAll('.header-dropdown.active').forEach(d => {
        d.classList.remove('active');
        d.querySelector('.dropdown-menu')?.classList.remove('show');
    });
}

function updateDashboardSection(section) {
    const pageTitle = document.querySelector('.page-title');
    if (!pageTitle) return;

    const titles = {
        dashboard: 'Dashboard Overview',
        core: 'Core Dashboard',
        helpdesk: 'Helpdesk Dashboard',
        parts: 'Parts Management',
        service: 'Service Management',
        tams: 'TAMS Analytics',
        scheduler: 'Scheduler',
    };
    pageTitle.textContent = titles[section] || 'Dashboard Overview';
    updateBreadcrumb(['Home', pageTitle.textContent]);
}

function updateBreadcrumb(items) {
    const breadcrumb = document.querySelector('.breadcrumb');
    if (!breadcrumb) return;
    breadcrumb.innerHTML = '';
    items.forEach((item, index) => {
        const span = document.createElement('span');
        span.textContent = item;
        breadcrumb.appendChild(span);
        if (index < items.length - 1) {
            const icon = document.createElement('span');
            icon.className = 'material-icons';
            icon.textContent = 'chevron_right';
            breadcrumb.appendChild(icon);
        }
    });
}

// ========================================
// MENU LAYOUT TOGGLE & COLLAPSE
// ========================================
function initializeLayoutToggle() {
    const toggleBtn = document.getElementById('menu-layout-toggle');
    if (!toggleBtn) return;

    const LAYOUT_STORAGE_KEY = 'dashboardMenuLayout';

    const menuIconButtons = document.querySelector('.menu-icon-buttons');
    const menuBarContainer = document.querySelector('.menu-bar .menu-container');
    const bookmarkBarActionsContainer = document.getElementById('bookmark-bar-actions');

    const applyLayout = (layout) => {
        const menuBar = document.querySelector('.menu-bar');
        
        document.body.classList.remove('sidebar-layout-active');
        if (menuBar) menuBar.classList.remove('collapsed');

        // Clean up any vertical menu artifacts before switching
        if (window.menuBarComponent) window.menuBarComponent.closeAllFlyouts();
        document.querySelectorAll('.menu-item.active-vertical').forEach(item => item.classList.remove('active-vertical'));


        if (layout === 'sidebar') {
            document.body.classList.add('sidebar-layout-active');
            if (menuBar) menuBar.classList.add('collapsed');
            
            if (bookmarkBarActionsContainer && menuIconButtons) {
                bookmarkBarActionsContainer.appendChild(menuIconButtons);
            }
            toggleBtn.title = 'Switch to Horizontal Menu';

        } else { // 'horizontal' layout
            if (menuBarContainer && menuIconButtons) {
                menuBarContainer.appendChild(menuIconButtons);
            }
            toggleBtn.title = 'Switch to Vertical Menu';
        }
        
        if (toggleBtn.querySelector('i')) {
            toggleBtn.querySelector('i').className = 'fas fa-bars';
        }

        if (window.populateBookmarks) {
            window.populateBookmarks();
        }
    };

    const savedLayout = localStorage.getItem(LAYOUT_STORAGE_KEY) || 'horizontal';
    applyLayout(savedLayout);

    toggleBtn.addEventListener('click', () => {
        const isSidebar = document.body.classList.contains('sidebar-layout-active');
        const newLayout = isSidebar ? 'horizontal' : 'sidebar';
        localStorage.setItem(LAYOUT_STORAGE_KEY, newLayout);
        applyLayout(newLayout);
    });
}

// ========================================
// SIDEBARS
// ========================================
function initializeSidebars() {
    const leftSidebar = document.getElementById('sidebar-left');
    const rightSidebar = document.getElementById('sidebar-right');
    const overlay = document.getElementById('sidebar-overlay');
    const toggleLeftBtn = document.getElementById('sidebar-toggle-left');
    const toggleRightBtn = document.getElementById('sidebar-toggle-right');
    const closeLeftBtn = document.getElementById('sidebar-left-close');
    const closeRightBtn = document.getElementById('sidebar-right-close');

    const closeAllSidebars = () => {
        leftSidebar?.classList.remove('active');
        rightSidebar?.classList.remove('active');
        overlay?.classList.remove('active');
        document.body.classList.remove('sidebar-left-is-active', 'sidebar-right-is-active');
    };

    const openSidebar = (sidebar) => {
        if (!sidebar || document.body.classList.contains('sidebar-layout-active')) return;
        const isActive = sidebar.classList.contains('active');

        if (window.menuBarComponent) window.menuBarComponent.closeAllDropdowns();
        closeAllSidebars();
        
        if (!isActive) {
            sidebar.classList.add('active');
            overlay?.classList.add('active');
            if (sidebar.id === 'sidebar-left') document.body.classList.add('sidebar-left-is-active');
            else if (sidebar.id === 'sidebar-right') document.body.classList.add('sidebar-right-is-active');
        }
    };

    toggleLeftBtn?.addEventListener('click', (e) => { e.stopPropagation(); openSidebar(leftSidebar); });
    toggleRightBtn?.addEventListener('click', (e) => { e.stopPropagation(); openSidebar(rightSidebar); });
    
    closeLeftBtn?.addEventListener('click', closeAllSidebars);
    closeRightBtn?.addEventListener('click', closeAllSidebars);
    overlay?.addEventListener('click', closeAllSidebars);
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeAllSidebars();
            if (window.menuBarComponent) window.menuBarComponent.closeAllDropdowns();
        }
    });
}

// ========================================
// BOOKMARKING & POPULATION
// ========================================
function initializeBookmarking() {
    const BOOKMARKS_STORAGE_KEY = 'dashboardBookmarks';

    const getBookmarks = () => JSON.parse(localStorage.getItem(BOOKMARKS_STORAGE_KEY) || '[]');
    const saveBookmarks = (bookmarks) => {
        localStorage.setItem(BOOKMARKS_STORAGE_KEY, JSON.stringify(bookmarks));
        if (window.populateBookmarks) window.populateBookmarks();
    };
    
    window.populateBookmarks = () => {
        const bookmarks = getBookmarks();
        const isSidebarLayout = document.body.classList.contains('sidebar-layout-active');
        
        const topBarContainer = document.getElementById('bookmark-list-top');
        const leftSidebarContainer = document.getElementById('bookmark-list-left');
        const rightSidebarContainer = document.getElementById('bookmark-list-right');
        
        if(topBarContainer) topBarContainer.innerHTML = '';
        if(leftSidebarContainer) leftSidebarContainer.innerHTML = '';
        if(rightSidebarContainer) rightSidebarContainer.innerHTML = '';

        const containers = isSidebarLayout 
            ? [topBarContainer] 
            : [leftSidebarContainer, rightSidebarContainer];
            
        containers.filter(Boolean).forEach(list => {
            if (bookmarks.length === 0) {
                if (!isSidebarLayout) list.innerHTML = `<p class="no-bookmarks-message">No bookmarks added yet.</p>`;
            } else {
                bookmarks.forEach(cardId => {
                    const originalCard = document.querySelector(`.mega-card[href="${cardId}"]`);
                    if (originalCard) {
                        const name = originalCard.querySelector('h4').textContent;
                        const iconClass = originalCard.querySelector('.mega-card-icon i').className;
                        
                        const bookmarkItem = document.createElement('a');
                        bookmarkItem.href = cardId;
                        bookmarkItem.className = 'bookmark-item';
                        bookmarkItem.innerHTML = `
                            <i class="${iconClass} bookmark-icon"></i>
                            <span class="bookmark-item-name">${name}</span>
                            <button class="bookmark-remove" data-id="${cardId}" title="Remove Bookmark">
                                <i class="fas fa-times"></i>
                            </button>
                        `;
                        list.appendChild(bookmarkItem);
                    }
                });
            }
        });
    };

    const updateStarAppearance = (starIcon, isBookmarked) => {
        starIcon.classList.toggle('bookmarked', isBookmarked);
        starIcon.classList.toggle('fas', isBookmarked);
        starIcon.classList.toggle('far', !isBookmarked);
    };

    const applyBookmarksOnLoad = () => {
        const bookmarks = getBookmarks();
        document.querySelectorAll('.mega-card .bookmark-star').forEach(starIcon => {
            const card = starIcon.closest('.mega-card');
            if (card) {
                const cardId = card.getAttribute('href');
                updateStarAppearance(starIcon, bookmarks.includes(cardId));
            }
        });
    };

    const handleBookmarkToggle = (starIcon) => {
        const card = starIcon.closest('.mega-card');
        const cardId = card?.getAttribute('href');
        if (!cardId) return;

        let bookmarks = getBookmarks();
        const isCurrentlyBookmarked = bookmarks.includes(cardId);

        bookmarks = isCurrentlyBookmarked
            ? bookmarks.filter(b => b !== cardId)
            : [...bookmarks, cardId];
        
        saveBookmarks(bookmarks);
        updateStarAppearance(starIcon, !isCurrentlyBookmarked);
    };

    const handleBookmarkRemove = (removeBtn) => {
        const cardId = removeBtn.dataset.id;
        if (!cardId) return;

        let bookmarks = getBookmarks();
        bookmarks = bookmarks.filter(b => b !== cardId);
        saveBookmarks(bookmarks);

        const starIcon = document.querySelector(`.mega-card[href="${cardId}"] .bookmark-star`);
        if (starIcon) updateStarAppearance(starIcon, false);
    };

    document.addEventListener('click', (e) => {
        const starIcon = e.target.closest('.bookmark-star');
        if (starIcon) {
            e.preventDefault();
            e.stopPropagation();
            handleBookmarkToggle(starIcon);
        }

        const removeBtn = e.target.closest('.bookmark-remove');
        if (removeBtn) {
            e.preventDefault();
            e.stopPropagation();
            handleBookmarkRemove(removeBtn);
        }
    });

    applyBookmarksOnLoad();
    console.log('Bookmarking system with responsive layout is active.');
}

// ==============================================================
// Menu Bar Component Functionality (UPDATED FOR FLYOUT MENU)
// ==============================================================
class MenuBarComponent {
    constructor() {
        this.activeDropdown = null;
        this.init();
    }

    init() {
        this.bindEvents();
        this.initializeTabs();
        this.initializeSearch();
        this.initializeModals();
        this.initializeUserManualSearch();
        console.log('Menu Bar Component initialized with flyout menu support.');
    }

    bindEvents() {
        document.querySelectorAll('.menu-button[data-dropdown]').forEach(button => {
            button.addEventListener('click', (e) => {
                e.stopPropagation();
                if (document.body.classList.contains('sidebar-layout-active')) {
                    this.handleVerticalMenuClick(button);
                } else {
                    this.toggleDropdown(button);
                }
            });
        });

        document.querySelectorAll('.icon-button[data-action]').forEach(button => {
            button.addEventListener('click', (e) => {
                const action = button.getAttribute('data-action');
                this.handleIconAction(action);
            });
        });

        document.addEventListener('click', (e) => {
            // Updated condition to not close when clicking inside a menu or its flyout
            if (!e.target.closest('.menu-item') && !e.target.closest('.flyout-panel')) {
                 this.closeAllDropdowns();
                 this.closeAllFlyouts();
            }
        });

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                 this.closeAllDropdowns();
                 this.closeAllFlyouts();
            }
        });
    }

    closeAllFlyouts() {
        const menuBar = document.querySelector('.menu-bar');
        
        // This is the key change: remove the class that forces the sidebar to stay open.
        if (menuBar) {
            menuBar.classList.remove('flyout-active');
        }

        document.querySelectorAll('.flyout-panel').forEach(panel => panel.remove());
        document.querySelectorAll('.menu-item.active-vertical').forEach(item => item.classList.remove('active-vertical'));
    }

    handleVerticalMenuClick(button) {
        const menuItem = button.closest('.menu-item');
        const menuBar = document.querySelector('.menu-bar');
        if (!menuItem || !menuBar) return;

        const wasActive = menuItem.classList.contains('active-vertical');
        
        // First, close any flyout that might already be open.
        // This will also remove 'flyout-active' and collapse the sidebar.
        this.closeAllFlyouts(); 

        // If the item we just clicked was NOT the one that was active,
        // we proceed to open its flyout.
        if (!wasActive) {
            // Add the class to force the sidebar to expand and stay open.
            menuBar.classList.add('flyout-active');
            
            // Mark the menu item as active to style it (e.g., rotate arrow).
            menuItem.classList.add('active-vertical');

            const dropdownId = button.getAttribute('data-dropdown');
            const originalDropdown = document.getElementById(`${dropdownId}-menu`);

            if (originalDropdown) {
                const flyoutPanel = this.createFlyoutPanel(originalDropdown);
                document.body.appendChild(flyoutPanel);
                // Use a short timeout to allow the element to be in the DOM before animating.
                setTimeout(() => flyoutPanel.classList.add('is-visible'), 10);
            }
        }
        // If the item was already active, the call to closeAllFlyouts() above will have
        // simply closed it, which is the desired toggle-off behavior.
    }

    createFlyoutPanel(originalDropdown) {
        const panel = document.createElement('div');
        panel.className = 'flyout-panel';

        const level2Container = document.createElement('div');
        level2Container.className = 'flyout-level2';
        
        const level3Container = document.createElement('div');
        level3Container.className = 'flyout-level3';

        originalDropdown.querySelectorAll('.mega-menu-tab').forEach((tab, index) => {
            const tabButton = document.createElement('button');
            tabButton.className = 'flyout-item-l2';
            tabButton.innerHTML = `<span>${tab.textContent}</span><i class="fas fa-chevron-right"></i>`;
            
            tabButton.addEventListener('click', () => {
                level2Container.querySelectorAll('.flyout-item-l2').forEach(btn => btn.classList.remove('active'));
                tabButton.classList.add('active');
                this.populateLevel3(level3Container, tab, originalDropdown);
                level3Container.scrollTop = 0; // Scroll to top of L3 content on tab change
            });

            level2Container.appendChild(tabButton);
            
            // Automatically select and display the first tab's content
            if (index === 0) {
                tabButton.classList.add('active');
                this.populateLevel3(level3Container, tab, originalDropdown);
            }
        });
        
        panel.appendChild(level2Container);
        panel.appendChild(level3Container);

        return panel;
    }

    populateLevel3(container, tab, originalDropdown) {
        container.innerHTML = ''; // Clear previous content

        const tabId = tab.dataset.tab;
        const contentId = `${tabId}-content`;
        const contentSource = originalDropdown.querySelector(`.mega-menu-tab-content[id$="${contentId}"], .mega-menu-tab-content[id^="${contentId}"]`);

        // Create and add the search bar for the L3 panel
        const searchContainer = document.createElement('div');
        searchContainer.className = 'flyout-search-container';
        searchContainer.innerHTML = `
            <i class="fas fa-search"></i>
            <input type="text" class="flyout-search-input" placeholder="Search in ${tab.textContent}...">
        `;
        container.appendChild(searchContainer);

        // Add a wrapper for the scrollable list
        const listWrapper = document.createElement('div');
        listWrapper.className = 'flyout-list-wrapper';
        container.appendChild(listWrapper);

        if (!contentSource || contentSource.querySelectorAll('.mega-card').length === 0) {
            listWrapper.innerHTML = `<div class="flyout-item-l3-empty">No items in this category.</div>`;
            return;
        }

        contentSource.querySelectorAll('.mega-card').forEach(card => {
            const link = document.createElement('a');
            link.href = card.getAttribute('href');
            link.className = 'flyout-item-l3';
            
            const titleText = card.querySelector('h4').textContent;
            const descriptionText = card.querySelector('p').textContent;

            link.innerHTML = `
                <div class="flyout-item-l3-title">${titleText}</div>
                <div class="flyout-item-l3-desc">${descriptionText}</div>
            `;
            listWrapper.appendChild(link);
        });

        // Add search functionality to the new L3 search input
        const searchInput = searchContainer.querySelector('.flyout-search-input');
        searchInput.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            let visibleItems = 0;
            listWrapper.querySelectorAll('.flyout-item-l3').forEach(item => {
                const itemText = item.textContent.toLowerCase();
                const isVisible = itemText.includes(searchTerm);
                item.style.display = isVisible ? 'block' : 'none';
                if(isVisible) visibleItems++;
            });

            // Handle "no results" message within the list
            let noResultsMsg = listWrapper.querySelector('.flyout-item-l3-empty');
            if (visibleItems === 0 && !noResultsMsg) {
                noResultsMsg = document.createElement('div');
                noResultsMsg.className = 'flyout-item-l3-empty';
                noResultsMsg.textContent = `No results for "${e.target.value}"`;
                listWrapper.appendChild(noResultsMsg);
            } else if (visibleItems > 0 && noResultsMsg) {
                noResultsMsg.remove();
            }
        });
    }

    // --- Original Methods (Unchanged from here) ---

    initializeModals() {
        document.querySelectorAll('.modal-close').forEach(button => {
            button.addEventListener('click', () => {
                const modal = button.closest('.modal-overlay');
                if (modal) this.hideModal(modal);
            });
        });

        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) this.hideModal(overlay);
            });
        });

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal-overlay.show').forEach(modal => this.hideModal(modal));
            }
        });

        const releaseNotesModal = document.getElementById('releaseNotesModal');
        if (releaseNotesModal) {
            const tabs = releaseNotesModal.querySelectorAll('.release-notes-tabs .tab-button');
            const contents = releaseNotesModal.querySelectorAll('.tab-content');

            tabs.forEach(tab => {
                tab.addEventListener('click', () => {
                    tabs.forEach(t => t.classList.remove('active'));
                    tab.classList.add('active');
                    const targetContentId = tab.dataset.tab === 'current' ? 'currentTab' : 'previousTab';
                    contents.forEach(content => {
                        content.classList.toggle('active', content.id === targetContentId);
                    });
                });
            });
        }
    }

    initializeUserManualSearch() {
        const searchInput = document.getElementById('userManualSearchInput');
        const contentArea = document.getElementById('userManualContent');
        const modal = document.getElementById('userManualModal');

        if (!searchInput || !contentArea || !modal) return;
        const originalHTML = contentArea.innerHTML;

        const performSearch = () => {
            const searchTerm = searchInput.value.trim();
            contentArea.innerHTML = originalHTML;
            if (searchTerm === '') return;
            const regex = new RegExp(`(${searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
            contentArea.innerHTML = contentArea.innerHTML.replace(regex, `<mark class="search-highlight">$1</mark>`);
        };

        searchInput.addEventListener('input', performSearch);
        new MutationObserver((mutations) => {
            if (mutations[0].attributeName === 'class' && !modal.classList.contains('show')) {
                 searchInput.value = '';
                 contentArea.innerHTML = originalHTML;
            }
        }).observe(modal, { attributes: true });
    }
    
    toggleDropdown(button) {
        const dropdownId = button.getAttribute('data-dropdown');
        const dropdown = document.getElementById(`${dropdownId}-menu`);
        const menuItem = button.closest('.menu-item');
        if (!dropdown || !menuItem) return;
        const isActive = menuItem.classList.contains('active');
        this.closeAllDropdowns();
        if (!isActive) this.openDropdown(dropdown, menuItem);
    }

    openDropdown(dropdown, menuItem) {
        dropdown.classList.add('active');
        menuItem.classList.add('active');
        this.activeDropdown = dropdown;
    }

    closeDropdown(dropdown) {
        if (!dropdown) return;
        dropdown.classList.remove('active');
        const menuItem = document.querySelector(`.menu-item.active`);
        if(menuItem) menuItem.classList.remove('active');
        if (this.activeDropdown === dropdown) this.activeDropdown = null;
    }

    closeAllDropdowns() {
        document.querySelectorAll('.dropdown-menu.active').forEach(d => this.closeDropdown(d));
    }

    initializeTabs() {
        document.querySelectorAll('.mega-menu-tab').forEach(button => {
            button.addEventListener('click', () => this.switchTab(button));
        });
    }

    switchTab(activeButton) {
        const tabId = activeButton.dataset.tab;
        const megaMenu = activeButton.closest('.dropdown-menu');
        if (!megaMenu) return;

        megaMenu.querySelectorAll('.mega-menu-tab').forEach(t => t.classList.remove('active'));
        activeButton.classList.add('active');
        
        megaMenu.querySelectorAll('.mega-menu-tab-content').forEach(c => c.classList.remove('active'));
        const content = megaMenu.querySelector(`.mega-menu-tab-content[id$="${tabId}-content"]`) || megaMenu.querySelector(`.mega-menu-tab-content[id^="${tabId}-content"]`);
        if (content) content.classList.add('active');
    }

    initializeSearch() {
        document.querySelectorAll('.mega-menu-search-input').forEach(input => {
            const clearBtn = input.parentElement.querySelector('.mega-menu-search-clear');
            input.addEventListener('input', () => this.handleSearch(input, clearBtn));
            if (clearBtn) clearBtn.addEventListener('click', () => this.clearSearch(input, clearBtn));
        });
    }

    handleSearch(input, clearBtn) {
        const term = input.value.toLowerCase().trim();
        const megaMenu = input.closest('.dropdown-menu');
        if (!megaMenu) return;
        if (clearBtn) clearBtn.style.display = term ? 'block' : 'none';
        megaMenu.querySelectorAll('.mega-card').forEach(card => {
            const text = card.textContent.toLowerCase();
            card.style.display = text.includes(term) ? 'flex' : 'none';
        });
    }

    clearSearch(input, clearBtn) {
        input.value = '';
        this.handleSearch(input, clearBtn);
        input.focus();
    }

    handleIconAction(action) {
        const modalMap = {
            'release-notes': 'releaseNotesModal',
            'dashboard-settings': 'customizeModal',
            'month-end-process': 'monthEndModal',
            'user-manual': 'userManualModal'
        };
        const modalId = modalMap[action];
        if (modalId) {
            const modal = document.getElementById(modalId);
            if(modal) this.showModal(modal);
        }
    }
    
    showModal(modal) {
        modal.classList.add('show');
        const modalContainer = modal.querySelector('.modal-container');
        if (modalContainer) {
            modalContainer.setAttribute('tabindex', '-1');
            modalContainer.focus();
        }
    }

    hideModal(modal) {
        modal.classList.remove('show');
        const modalContainer = modal.querySelector('.modal-container');
        if (modalContainer) modalContainer.removeAttribute('tabindex');
    }
}

// Initialize the menu bar component after other scripts
setTimeout(() => {
    window.menuBarComponent = new MenuBarComponent();
}, 100);
