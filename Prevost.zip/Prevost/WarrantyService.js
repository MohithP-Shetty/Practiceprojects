const Stage1Div1 = document.querySelector(".Stage1-Div1");
const Stage1Div2 = document.querySelector(".Stage1-Div2");

function hanadelStage1div2 (){
    if (document.querySelector(".Stage1-Div2")){
        return document.querySelector(".Stage1-Div2")
    }
    else {
        return document.querySelector(".Stage1-Div2-V2 ")
    }
}

function EnterStage1Div2(event)  {
    const Target = event.target;
     if (Stage1Div2.classList.contains('.Stage1-Div2')) {
     Stage1Div2.classList.remove('.Stage1-Div2');
     Target.classList.add('.Stage1-Div2-V2');
    } else {
     console.log("  ")
 }
}

function ExitStage1Div2(event){
    const target = event.target;
     if (Stage1Div2.classList.contains('.Stage1-Div2-V2')) {
     Stage1Div2.classList.remove('.Stage1-Div2-V2');
     Target.classList.add('.Stage1-Div2');
    } else {
     console.log("  ")
 }
}

Stage1Div1.addEventListener('mouseenter' , EnterStage1Div2 )
Stage1Div1.addEventListener('mouseout' , ExitStage1Div2 )